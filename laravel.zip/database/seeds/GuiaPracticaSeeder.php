<?php

use Illuminate\Database\Seeder;
use App\Models\GuiaPractica;

class GuiaPracticaSeeder extends Seeder
{
    public function run()
    {
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
        
        GuiaPractica::create([
        	'archivo' 		        =>	'guia_practica.pdf',
        ]);
    }
}
