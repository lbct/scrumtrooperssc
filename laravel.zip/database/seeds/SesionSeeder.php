<?php

use Illuminate\Database\Seeder;
use App\Models\Sesion;

class SesionSeeder extends Seeder
{
    public function run()
    {
        include 'poblacion/SesionSeeder.php';
    }
}
