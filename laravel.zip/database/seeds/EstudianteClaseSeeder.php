<?php

use Illuminate\Database\Seeder;
use App\Models\EstudianteClase;

class EstudianteClaseSeeder extends Seeder
{
    public function run()
    {
        include 'poblacion/EstudianteClaseSeeder.php';
    }
}
