<?php use App\Models\SesionEstudiante;
SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 1,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 2,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 3,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 4,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 5,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 6,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 7,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 8,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 9,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 10,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 11,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 12,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 13,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 14,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 15,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 16,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 17,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 18,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 19,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 20,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 21,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 22,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 23,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 24,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 25,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 26,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 27,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 28,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 29,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 30,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 31,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 32,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 33,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 34,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 35,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 1,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 2,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 3,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 4,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 5,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 6,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 7,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 8,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 9,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 10,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 11,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 12,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 13,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 14,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 15,
'estudiante_clase_id' => 36,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 37,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 38,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 39,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 40,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 41,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 42,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 43,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 44,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 45,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 46,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 47,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 48,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 49,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 50,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 51,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 52,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 53,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 54,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 55,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 56,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 57,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 58,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 59,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 60,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 61,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 62,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 63,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 64,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 65,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 66,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 67,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 68,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 69,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 70,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 16,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 17,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 18,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 19,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 20,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 21,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 22,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 23,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 24,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 25,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 26,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 27,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 28,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 29,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 30,
'estudiante_clase_id' => 71,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 72,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 73,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 74,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 75,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 76,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 77,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 78,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 79,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 80,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 81,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 82,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 83,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 84,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 85,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 86,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 87,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 88,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 89,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 90,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 91,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 92,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 93,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 94,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 95,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 96,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 97,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 98,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 99,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 31,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 32,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 33,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 34,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 35,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 36,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 37,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 38,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 39,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 40,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 41,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 42,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 43,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 44,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 45,
'estudiante_clase_id' => 100,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 101,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 102,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 103,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 104,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 105,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 106,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 107,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 108,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 109,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 110,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 111,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 112,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 113,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 114,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 115,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 116,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 117,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 118,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 119,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 120,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 121,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 122,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 123,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 124,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 125,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 126,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 127,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 128,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 129,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 130,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 131,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 132,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 46,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 47,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 48,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 49,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 50,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 51,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 52,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 53,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 54,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 55,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 56,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 57,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 58,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 59,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 60,
'estudiante_clase_id' => 133,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 134,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 135,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 136,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 137,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 138,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 139,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 140,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 141,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 142,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 143,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 144,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 145,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 146,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 147,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 148,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 149,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 150,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 151,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 152,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 153,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 154,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 155,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 156,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 157,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 158,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 159,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 160,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 161,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 162,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 163,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 164,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 165,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 166,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 167,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 61,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 62,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 63,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 64,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 65,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 66,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 67,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 68,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 69,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 70,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 71,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 72,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 73,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 74,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 75,
'estudiante_clase_id' => 168,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 169,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 170,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 171,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 172,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 173,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 174,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 175,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 176,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 177,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 178,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 179,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 180,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 181,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 182,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 183,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 184,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 185,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 186,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 76,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 77,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 78,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 79,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 80,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 81,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 82,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 83,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 84,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 85,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 86,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 87,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 88,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 89,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 90,
'estudiante_clase_id' => 187,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 188,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 189,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 190,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 191,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 192,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 193,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 194,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 195,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 196,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 197,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 198,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 199,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 200,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 201,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 202,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 203,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 204,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 205,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 206,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 207,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 208,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 209,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 210,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 211,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 212,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 213,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 214,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 215,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 216,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 217,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 91,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 92,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 93,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 94,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 95,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 96,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 97,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 98,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 99,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 100,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 101,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 102,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 103,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 104,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 105,
'estudiante_clase_id' => 218,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 219,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 220,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 221,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 222,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 223,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 224,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 225,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 226,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 227,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 228,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 229,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 230,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 231,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 232,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 233,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 234,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 235,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 236,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 237,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 238,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 239,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 240,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 241,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 242,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 243,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 244,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 245,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 246,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 247,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 248,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 249,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 106,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 107,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 108,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 109,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 110,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 111,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 112,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 113,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 114,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 115,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 116,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 117,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 118,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 119,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 120,
'estudiante_clase_id' => 250,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 251,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 252,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 253,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 254,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 255,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 256,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 257,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 258,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 259,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 260,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 261,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 262,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 263,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 264,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 265,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 266,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 267,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 268,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 269,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 270,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 271,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 272,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 273,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 274,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 275,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 276,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 277,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 278,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 279,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 280,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 281,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 282,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 283,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 121,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 122,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 123,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 124,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 125,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 126,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 127,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 128,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 129,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 130,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 131,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 132,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 133,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

SesionEstudiante::create([
'sesion_id'           => 134,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 0,
]);

SesionEstudiante::create([
'sesion_id'           => 135,
'estudiante_clase_id' => 284,
'asistencia_sesion'   => 1,
]);

