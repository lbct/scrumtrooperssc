<?php use App\Models\EstudianteClase;
EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 1,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 2,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 3,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 4,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 5,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 6,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 7,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 8,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 9,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 10,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 11,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 12,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 13,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 14,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 15,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 16,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 17,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 18,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 19,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 20,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 21,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 22,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 23,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 24,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 25,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 26,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 27,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 28,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 29,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 30,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 31,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 32,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 33,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 34,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 35,
]);

EstudianteClase::create([
'clase_id'           => 1,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 36,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 37,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 38,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 39,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 40,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 41,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 42,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 43,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 44,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 45,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 46,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 47,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 48,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 49,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 50,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 51,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 52,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 53,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 54,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 55,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 56,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 57,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 58,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 59,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 60,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 61,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 62,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 63,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 64,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 65,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 66,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 67,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 68,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 69,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 70,
]);

EstudianteClase::create([
'clase_id'           => 2,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 71,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 72,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 73,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 74,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 75,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 76,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 77,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 78,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 79,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 80,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 81,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 82,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 83,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 84,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 85,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 86,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 87,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 88,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 89,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 90,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 91,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 92,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 93,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 94,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 95,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 96,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 97,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 98,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 99,
]);

EstudianteClase::create([
'clase_id'           => 3,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 100,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 101,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 102,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 103,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 104,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 105,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 106,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 107,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 108,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 109,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 110,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 111,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 112,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 113,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 114,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 115,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 116,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 117,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 118,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 119,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 120,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 121,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 122,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 123,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 124,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 125,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 126,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 127,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 128,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 129,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 130,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 131,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 132,
]);

EstudianteClase::create([
'clase_id'           => 4,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 133,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 134,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 135,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 136,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 137,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 138,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 139,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 140,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 141,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 142,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 143,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 144,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 145,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 146,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 147,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 148,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 149,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 150,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 151,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 152,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 153,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 154,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 155,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 156,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 157,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 158,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 159,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 160,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 161,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 162,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 163,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 164,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 165,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 166,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 167,
]);

EstudianteClase::create([
'clase_id'           => 5,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 168,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 169,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 170,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 171,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 172,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 173,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 174,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 175,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 176,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 177,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 178,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 179,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 180,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 181,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 182,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 183,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 184,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 185,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 186,
]);

EstudianteClase::create([
'clase_id'           => 6,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 187,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 188,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 189,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 190,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 191,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 192,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 193,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 194,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 195,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 196,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 197,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 198,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 199,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 200,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 201,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 202,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 203,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 204,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 205,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 206,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 207,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 208,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 209,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 210,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 211,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 212,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 213,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 214,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 215,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 216,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 217,
]);

EstudianteClase::create([
'clase_id'           => 7,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 218,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 219,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 220,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 221,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 222,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 223,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 224,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 225,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 226,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 227,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 228,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 229,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 230,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 231,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 232,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 233,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 234,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 235,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 236,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 237,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 238,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 239,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 240,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 241,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 242,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 243,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 244,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 245,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 246,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 247,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 248,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 249,
]);

EstudianteClase::create([
'clase_id'           => 8,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 250,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 251,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 252,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 253,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 254,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 255,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 256,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 257,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 258,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 259,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 260,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 261,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 262,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 263,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 264,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 265,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 266,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 267,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 268,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 269,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 270,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 271,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 272,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 273,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 274,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 275,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 276,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 277,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 278,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 3,
'estudiante_id'      => 279,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 280,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 281,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 2,
'estudiante_id'      => 282,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 283,
]);

EstudianteClase::create([
'clase_id'           => 9,
'grupo_a_docente_id' => 1,
'estudiante_id'      => 284,
]);

