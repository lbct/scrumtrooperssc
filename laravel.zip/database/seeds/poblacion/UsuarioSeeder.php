<?php use App\Models\Usuario;
Usuario::create([
'username' => 'AdrianaVelardeC.',
'password' => Hash::make('texto'),
'nombre'   => 'Adriana ',
'apellido' => 'Velarde C.',
'correo'   => 'Adriana.Velarde.C.@gmail.com',
]);

Usuario::create([
'username' => 'ArielSergioRodriguezMilan',
'password' => Hash::make('texto'),
'nombre'   => 'Ariel ',
'apellido' => 'Sergio Rodriguez Milan',
'correo'   => 'Ariel.Sergio.Rodriguez.Milan@gmail.com',
]);

Usuario::create([
'username' => 'ArielWilliamMejiaLazarte',
'password' => Hash::make('texto'),
'nombre'   => 'Ariel ',
'apellido' => 'William Mejia Lazarte',
'correo'   => 'Ariel.William.Mejia.Lazarte@gmail.com',
]);

Usuario::create([
'username' => 'ArnoldCopaFlores',
'password' => Hash::make('texto'),
'nombre'   => 'Arnold ',
'apellido' => 'Copa Flores',
'correo'   => 'Arnold.Copa.Flores@gmail.com',
]);

Usuario::create([
'username' => 'CarlaVeraniceArgotePinto',
'password' => Hash::make('texto'),
'nombre'   => 'Carla ',
'apellido' => 'Veranice Argote Pinto',
'correo'   => 'Carla.Veranice.Argote.Pinto@gmail.com',
]);

Usuario::create([
'username' => 'CeciliaVergaraZeballos',
'password' => Hash::make('texto'),
'nombre'   => 'Cecilia ',
'apellido' => 'Vergara Zeballos',
'correo'   => 'Cecilia.Vergara.Zeballos@gmail.com',
]);

Usuario::create([
'username' => 'CristianCharlieApazaGutierrez',
'password' => Hash::make('texto'),
'nombre'   => 'Cristian ',
'apellido' => 'Charlie ApazaGutierrez',
'correo'   => 'Cristian.Charlie.ApazaGutierrez@gmail.com',
]);

Usuario::create([
'username' => 'CruzLunaLeonardoAlvaro',
'password' => Hash::make('texto'),
'nombre'   => 'Cruz ',
'apellido' => 'Luna Leonardo Alvaro',
'correo'   => 'Cruz.Luna.Leonardo.Alvaro@gmail.com',
]);

Usuario::create([
'username' => 'GaryRocaValencia',
'password' => Hash::make('texto'),
'nombre'   => 'Gary ',
'apellido' => 'Roca Valencia',
'correo'   => 'Gary.Roca.Valencia@gmail.com',
]);

Usuario::create([
'username' => 'GiulianoNicolaHuancaVerduguez',
'password' => Hash::make('texto'),
'nombre'   => 'Giuliano ',
'apellido' => 'Nicola Huanca Verduguez',
'correo'   => 'Giuliano.Nicola.Huanca.Verduguez@gmail.com',
]);

Usuario::create([
'username' => 'IvanDouglasAlarconCastro',
'password' => Hash::make('texto'),
'nombre'   => 'Ivan ',
'apellido' => 'Douglas Alarcon Castro',
'correo'   => 'Ivan.Douglas.Alarcon.Castro@gmail.com',
]);

Usuario::create([
'username' => 'JhosepTintaMancilla',
'password' => Hash::make('texto'),
'nombre'   => 'Jhosep ',
'apellido' => 'Tinta Mancilla',
'correo'   => 'Jhosep.Tinta.Mancilla@gmail.com',
]);

Usuario::create([
'username' => 'JorgeJairCondoriRequena',
'password' => Hash::make('texto'),
'nombre'   => 'Jorge ',
'apellido' => 'Jair Condori Requena',
'correo'   => 'Jorge.Jair.Condori.Requena@gmail.com',
]);

Usuario::create([
'username' => 'JoselynneBelenTorrico',
'password' => Hash::make('texto'),
'nombre'   => 'Joselynne ',
'apellido' => 'Belen Torrico',
'correo'   => 'Joselynne.Belen.Torrico@gmail.com',
]);

Usuario::create([
'username' => 'JuanI.Romero',
'password' => Hash::make('texto'),
'nombre'   => 'Juan ',
'apellido' => 'I. Romero',
'correo'   => 'Juan.I..Romero@gmail.com',
]);

Usuario::create([
'username' => 'KaterinOjedaPozo',
'password' => Hash::make('texto'),
'nombre'   => 'Katerin ',
'apellido' => 'Ojeda Pozo',
'correo'   => 'Katerin.Ojeda.Pozo@gmail.com',
]);

Usuario::create([
'username' => 'KevinJonatanYanaQuispe',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Jonatan Yana Quispe',
'correo'   => 'Kevin.Jonatan.Yana.Quispe@gmail.com',
]);

Usuario::create([
'username' => 'MadaiFloresModragon',
'password' => Hash::make('texto'),
'nombre'   => 'Madai ',
'apellido' => 'Flores Modragon',
'correo'   => 'Madai.Flores.Modragon@gmail.com',
]);

Usuario::create([
'username' => 'MarianaNathalyVillarroelVargas',
'password' => Hash::make('texto'),
'nombre'   => 'Mariana ',
'apellido' => 'Nathaly Villarroel Vargas',
'correo'   => 'Mariana.Nathaly.Villarroel.Vargas@gmail.com',
]);

Usuario::create([
'username' => 'MauricioOscarCrespoMonta�o',
'password' => Hash::make('texto'),
'nombre'   => 'Mauricio ',
'apellido' => 'Oscar Crespo Monta�o',
'correo'   => 'Mauricio.Oscar.Crespo.Monta�o@gmail.com',
]);

Usuario::create([
'username' => 'NekBrayanFerrufinoTola',
'password' => Hash::make('texto'),
'nombre'   => 'Nek ',
'apellido' => 'Brayan Ferrufino Tola',
'correo'   => 'Nek.Brayan.Ferrufino.Tola@gmail.com',
]);

Usuario::create([
'username' => 'NicoleRojasZambrana',
'password' => Hash::make('texto'),
'nombre'   => 'Nicole ',
'apellido' => 'Rojas Zambrana',
'correo'   => 'Nicole.Rojas.Zambrana@gmail.com',
]);

Usuario::create([
'username' => 'NinethAdelaPinaya',
'password' => Hash::make('texto'),
'nombre'   => 'Nineth ',
'apellido' => 'Adela Pinaya',
'correo'   => 'Nineth.Adela.Pinaya@gmail.com',
]);

Usuario::create([
'username' => 'NoelGarciaMejia',
'password' => Hash::make('texto'),
'nombre'   => 'Noel ',
'apellido' => 'Garcia Mejia',
'correo'   => 'Noel.Garcia.Mejia@gmail.com',
]);

Usuario::create([
'username' => 'PabloSaulMagui�aApaza',
'password' => Hash::make('texto'),
'nombre'   => 'Pablo ',
'apellido' => 'Saul Magui�a Apaza',
'correo'   => 'Pablo.Saul.Magui�a.Apaza@gmail.com',
]);

Usuario::create([
'username' => 'PaolaAndreaVillcaMaiza',
'password' => Hash::make('texto'),
'nombre'   => 'Paola ',
'apellido' => 'Andrea Villca Maiza',
'correo'   => 'Paola.Andrea.Villca.Maiza@gmail.com',
]);

Usuario::create([
'username' => 'RashelEymiParraLopez',
'password' => Hash::make('texto'),
'nombre'   => 'Rashel ',
'apellido' => 'Eymi Parra Lopez',
'correo'   => 'Rashel.Eymi.Parra.Lopez@gmail.com',
]);

Usuario::create([
'username' => 'RimerSaulRosaHerrera',
'password' => Hash::make('texto'),
'nombre'   => 'Rimer ',
'apellido' => 'Saul Rosa Herrera',
'correo'   => 'Rimer.Saul.Rosa.Herrera@gmail.com',
]);

Usuario::create([
'username' => 'RodrigoQuenaCalizaya',
'password' => Hash::make('texto'),
'nombre'   => 'Rodrigo ',
'apellido' => 'Quena Calizaya',
'correo'   => 'Rodrigo.Quena.Calizaya@gmail.com',
]);

Usuario::create([
'username' => 'RogerRudyEspinozaRios',
'password' => Hash::make('texto'),
'nombre'   => 'Roger ',
'apellido' => 'Rudy Espinoza Rios',
'correo'   => 'Roger.Rudy.Espinoza.Rios@gmail.com',
]);

Usuario::create([
'username' => 'RomelAlainMedinaVelasco',
'password' => Hash::make('texto'),
'nombre'   => 'Romel ',
'apellido' => 'Alain Medina Velasco',
'correo'   => 'Romel.Alain.Medina.Velasco@gmail.com',
]);

Usuario::create([
'username' => 'WaldoCruzZurita',
'password' => Hash::make('texto'),
'nombre'   => 'Waldo ',
'apellido' => 'Cruz Zurita',
'correo'   => 'Waldo.Cruz.Zurita@gmail.com',
]);

Usuario::create([
'username' => 'WenddyMarielRomeroNina',
'password' => Hash::make('texto'),
'nombre'   => 'Wenddy ',
'apellido' => 'Mariel Romero Nina',
'correo'   => 'Wenddy.Mariel.Romero.Nina@gmail.com',
]);

Usuario::create([
'username' => 'WilderMeridaArista',
'password' => Hash::make('texto'),
'nombre'   => 'Wilder ',
'apellido' => 'Merida Arista',
'correo'   => 'Wilder.Merida.Arista@gmail.com',
]);

Usuario::create([
'username' => 'YesuaJimenezGonzales',
'password' => Hash::make('texto'),
'nombre'   => 'Yesua ',
'apellido' => 'Jimenez Gonzales',
'correo'   => 'Yesua.Jimenez.Gonzales@gmail.com',
]);

Usuario::create([
'username' => 'EvelinTiconaJachacollo',
'password' => Hash::make('texto'),
'nombre'   => 'Evelin ',
'apellido' => 'Ticona Jachacollo',
'correo'   => 'Evelin.Ticona.Jachacollo@gmail.com',
]);

Usuario::create([
'username' => 'AldairNelsonTorrezQuiroga',
'password' => Hash::make('texto'),
'nombre'   => 'Aldair ',
'apellido' => 'Nelson Torrez Quiroga',
'correo'   => 'Aldair.Nelson.Torrez.Quiroga@gmail.com',
]);

Usuario::create([
'username' => 'AlejandroFuentes',
'password' => Hash::make('texto'),
'nombre'   => 'Alejandro ',
'apellido' => 'Fuentes',
'correo'   => 'Alejandro.Fuentes@gmail.com',
]);

Usuario::create([
'username' => 'AndresBravoAguilar',
'password' => Hash::make('texto'),
'nombre'   => 'Andres ',
'apellido' => 'Bravo Aguilar',
'correo'   => 'Andres.Bravo.Aguilar@gmail.com',
]);

Usuario::create([
'username' => 'BernabeCatariColque',
'password' => Hash::make('texto'),
'nombre'   => 'Bernabe ',
'apellido' => 'Catari Colque',
'correo'   => 'Bernabe.Catari.Colque@gmail.com',
]);

Usuario::create([
'username' => 'BrisaRojaBang',
'password' => Hash::make('texto'),
'nombre'   => 'Brisa ',
'apellido' => 'Roja Bang',
'correo'   => 'Brisa.Roja.Bang@gmail.com',
]);

Usuario::create([
'username' => 'CarlosJosueVasquesHuanca',
'password' => Hash::make('texto'),
'nombre'   => 'Carlos ',
'apellido' => 'Josue Vasques Huanca',
'correo'   => 'Carlos.Josue.Vasques.Huanca@gmail.com',
]);

Usuario::create([
'username' => 'DiegoFabricioSandovalChumacero',
'password' => Hash::make('texto'),
'nombre'   => 'Diego ',
'apellido' => 'Fabricio Sandoval Chumacero',
'correo'   => 'Diego.Fabricio.Sandoval.Chumacero@gmail.com',
]);

Usuario::create([
'username' => 'EdilsonAliagaGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Edilson ',
'apellido' => 'Aliaga Garcia',
'correo'   => 'Edilson.Aliaga.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'GroverChuraFlores',
'password' => Hash::make('texto'),
'nombre'   => 'Grover ',
'apellido' => 'Chura Flores',
'correo'   => 'Grover.Chura.Flores@gmail.com',
]);

Usuario::create([
'username' => 'GuillermoRojasBecerra',
'password' => Hash::make('texto'),
'nombre'   => 'Guillermo ',
'apellido' => 'Rojas Becerra',
'correo'   => 'Guillermo.Rojas.Becerra@gmail.com',
]);

Usuario::create([
'username' => 'IsmaelPeraltaFernandez',
'password' => Hash::make('texto'),
'nombre'   => 'Ismael ',
'apellido' => 'Peralta Fernandez',
'correo'   => 'Ismael.Peralta.Fernandez@gmail.com',
]);

Usuario::create([
'username' => 'IvanFloresCalle',
'password' => Hash::make('texto'),
'nombre'   => 'Ivan ',
'apellido' => 'Flores Calle',
'correo'   => 'Ivan.Flores.Calle@gmail.com',
]);

Usuario::create([
'username' => 'IvanGomezOrellanda',
'password' => Hash::make('texto'),
'nombre'   => 'Ivan ',
'apellido' => 'Gomez Orellanda',
'correo'   => 'Ivan.Gomez.Orellanda@gmail.com',
]);

Usuario::create([
'username' => 'JheisonLeon',
'password' => Hash::make('texto'),
'nombre'   => 'Jheison ',
'apellido' => 'Leon',
'correo'   => 'Jheison.Leon@gmail.com',
]);

Usuario::create([
'username' => 'JhoelMaicolMurilloCoca',
'password' => Hash::make('texto'),
'nombre'   => 'Jhoel ',
'apellido' => 'Maicol Murillo Coca',
'correo'   => 'Jhoel.Maicol.Murillo.Coca@gmail.com',
]);

Usuario::create([
'username' => 'JhoelRojasValdez',
'password' => Hash::make('texto'),
'nombre'   => 'Jhoel ',
'apellido' => 'Rojas Valdez',
'correo'   => 'Jhoel.Rojas.Valdez@gmail.com',
]);

Usuario::create([
'username' => 'JhonatanCuencaPilco',
'password' => Hash::make('texto'),
'nombre'   => 'Jhonatan ',
'apellido' => 'Cuenca Pilco',
'correo'   => 'Jhonatan.Cuenca.Pilco@gmail.com',
]);

Usuario::create([
'username' => 'JonathanMayreNoguera',
'password' => Hash::make('texto'),
'nombre'   => 'Jonathan ',
'apellido' => 'Mayre Noguera',
'correo'   => 'Jonathan.Mayre.Noguera@gmail.com',
]);

Usuario::create([
'username' => 'JoseQuiroz',
'password' => Hash::make('texto'),
'nombre'   => 'Jose ',
'apellido' => 'Quiroz',
'correo'   => 'Jose.Quiroz@gmail.com',
]);

Usuario::create([
'username' => 'JosueInturiasS.',
'password' => Hash::make('texto'),
'nombre'   => 'Josue ',
'apellido' => 'Inturias S.',
'correo'   => 'Josue.Inturias.S.@gmail.com',
]);

Usuario::create([
'username' => 'KatherineOrtizMamani',
'password' => Hash::make('texto'),
'nombre'   => 'Katherine ',
'apellido' => 'Ortiz Mamani',
'correo'   => 'Katherine.Ortiz.Mamani@gmail.com',
]);

Usuario::create([
'username' => 'KevinRaulUre�aVidal',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Raul Ure�a Vidal',
'correo'   => 'Kevin.Raul.Ure�a.Vidal@gmail.com',
]);

Usuario::create([
'username' => 'KevinVillarroelChauca',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Villarroel Chauca',
'correo'   => 'Kevin.Villarroel.Chauca@gmail.com',
]);

Usuario::create([
'username' => 'LizbethPacariMamani',
'password' => Hash::make('texto'),
'nombre'   => 'Lizbeth ',
'apellido' => 'Pacari Mamani',
'correo'   => 'Lizbeth.Pacari.Mamani@gmail.com',
]);

Usuario::create([
'username' => 'LuisVeidmarChoqueDuran',
'password' => Hash::make('texto'),
'nombre'   => 'Luis ',
'apellido' => 'Veidmar Choque Duran',
'correo'   => 'Luis.Veidmar.Choque.Duran@gmail.com',
]);

Usuario::create([
'username' => 'MarcosJulioRamosCaceres',
'password' => Hash::make('texto'),
'nombre'   => 'Marcos ',
'apellido' => 'Julio Ramos Caceres',
'correo'   => 'Marcos.Julio.Ramos.Caceres@gmail.com',
]);

Usuario::create([
'username' => 'MauricioHuaytaVillanueva',
'password' => Hash::make('texto'),
'nombre'   => 'Mauricio ',
'apellido' => 'Huayta Villanueva',
'correo'   => 'Mauricio.Huayta.Villanueva@gmail.com',
]);

Usuario::create([
'username' => 'OmarAndresSelayaAntelo',
'password' => Hash::make('texto'),
'nombre'   => 'Omar ',
'apellido' => 'Andres Selaya Antelo',
'correo'   => 'Omar.Andres.Selaya.Antelo@gmail.com',
]);

Usuario::create([
'username' => 'PabloRomanYaveMagne',
'password' => Hash::make('texto'),
'nombre'   => 'Pablo ',
'apellido' => 'Roman Yave Magne',
'correo'   => 'Pablo.Roman.Yave.Magne@gmail.com',
]);

Usuario::create([
'username' => 'RodrigoOliveraNavia',
'password' => Hash::make('texto'),
'nombre'   => 'Rodrigo ',
'apellido' => 'Olivera Navia',
'correo'   => 'Rodrigo.Olivera.Navia@gmail.com',
]);

Usuario::create([
'username' => 'RolandoGuilleEscalera',
'password' => Hash::make('texto'),
'nombre'   => 'Rolando ',
'apellido' => 'Guille Escalera',
'correo'   => 'Rolando.Guille.Escalera@gmail.com',
]);

Usuario::create([
'username' => 'SantiagoEdwingBravoB.',
'password' => Hash::make('texto'),
'nombre'   => 'Santiago ',
'apellido' => 'Edwing Bravo B.',
'correo'   => 'Santiago.Edwing.Bravo.B.@gmail.com',
]);

Usuario::create([
'username' => 'UlisesMaldonadoEspejo',
'password' => Hash::make('texto'),
'nombre'   => 'Ulises ',
'apellido' => 'Maldonado Espejo',
'correo'   => 'Ulises.Maldonado.Espejo@gmail.com',
]);

Usuario::create([
'username' => 'VeymarHinojosaJuan',
'password' => Hash::make('texto'),
'nombre'   => 'Veymar ',
'apellido' => 'Hinojosa Juan',
'correo'   => 'Veymar.Hinojosa.Juan@gmail.com',
]);

Usuario::create([
'username' => 'WillmarHuarachiGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Willmar ',
'apellido' => 'Huarachi Garcia',
'correo'   => 'Willmar.Huarachi.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'AbigailElisaGalzinBazoalto',
'password' => Hash::make('texto'),
'nombre'   => 'Abigail ',
'apellido' => 'Elisa Galzin Bazoalto',
'correo'   => 'Abigail.Elisa.Galzin.Bazoalto@gmail.com',
]);

Usuario::create([
'username' => 'AlbaAnierMontenegroAngulo',
'password' => Hash::make('texto'),
'nombre'   => 'Alba ',
'apellido' => 'Anier Montenegro Angulo',
'correo'   => 'Alba.Anier.Montenegro.Angulo@gmail.com',
]);

Usuario::create([
'username' => 'AlbertoMamani',
'password' => Hash::make('texto'),
'nombre'   => 'Alberto ',
'apellido' => 'Mamani',
'correo'   => 'Alberto.Mamani@gmail.com',
]);

Usuario::create([
'username' => 'AngelaAndresSalvatierraCabrera',
'password' => Hash::make('texto'),
'nombre'   => 'Angela ',
'apellido' => 'Andres Salvatierra Cabrera',
'correo'   => 'Angela.Andres.Salvatierra.Cabrera@gmail.com',
]);

Usuario::create([
'username' => 'ArrayaGuzmanEduardoJosue',
'password' => Hash::make('texto'),
'nombre'   => 'Arraya ',
'apellido' => 'Guzman Eduardo Josue',
'correo'   => 'Arraya.Guzman.Eduardo.Josue@gmail.com',
]);

Usuario::create([
'username' => 'CarlosFernandoRojas',
'password' => Hash::make('texto'),
'nombre'   => 'Carlos ',
'apellido' => 'Fernando Rojas',
'correo'   => 'Carlos.Fernando.Rojas@gmail.com',
]);

Usuario::create([
'username' => 'DanielPerezGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Daniel ',
'apellido' => 'Perez Garcia',
'correo'   => 'Daniel.Perez.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'EdsonGabrielCespedesDelgadillo',
'password' => Hash::make('texto'),
'nombre'   => 'Edson ',
'apellido' => 'Gabriel Cespedes Delgadillo',
'correo'   => 'Edson.Gabriel.Cespedes.Delgadillo@gmail.com',
]);

Usuario::create([
'username' => 'FabricioHuariSiles',
'password' => Hash::make('texto'),
'nombre'   => 'Fabricio ',
'apellido' => 'Huari Siles',
'correo'   => 'Fabricio.Huari.Siles@gmail.com',
]);

Usuario::create([
'username' => 'IsaiMagdielQuispePerez',
'password' => Hash::make('texto'),
'nombre'   => 'Isai ',
'apellido' => 'Magdiel Quispe Perez',
'correo'   => 'Isai.Magdiel.Quispe.Perez@gmail.com',
]);

Usuario::create([
'username' => 'JosueLaraPaqui',
'password' => Hash::make('texto'),
'nombre'   => 'Josue ',
'apellido' => 'Lara Paqui',
'correo'   => 'Josue.Lara.Paqui@gmail.com',
]);

Usuario::create([
'username' => 'JuanGabrielSalazarV.',
'password' => Hash::make('texto'),
'nombre'   => 'Juan ',
'apellido' => 'Gabriel Salazar V.',
'correo'   => 'Juan.Gabriel.Salazar.V.@gmail.com',
]);

Usuario::create([
'username' => 'JulioAlvaroIglesiasHuarachi',
'password' => Hash::make('texto'),
'nombre'   => 'Julio ',
'apellido' => 'Alvaro Iglesias Huarachi',
'correo'   => 'Julio.Alvaro.Iglesias.Huarachi@gmail.com',
]);

Usuario::create([
'username' => 'KarenChoquecallata',
'password' => Hash::make('texto'),
'nombre'   => 'Karen ',
'apellido' => 'Choquecallata',
'correo'   => 'Karen.Choquecallata@gmail.com',
]);

Usuario::create([
'username' => 'KevinDannyPoma',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Danny Poma',
'correo'   => 'Kevin.Danny.Poma@gmail.com',
]);

Usuario::create([
'username' => 'MauricioCocaNavarro',
'password' => Hash::make('texto'),
'nombre'   => 'Mauricio ',
'apellido' => 'Coca Navarro',
'correo'   => 'Mauricio.Coca.Navarro@gmail.com',
]);

Usuario::create([
'username' => 'MauricioDavidOrtu�oAhenke',
'password' => Hash::make('texto'),
'nombre'   => 'Mauricio ',
'apellido' => 'David Ortu�o Ahenke',
'correo'   => 'Mauricio.David.Ortu�o.Ahenke@gmail.com',
]);

Usuario::create([
'username' => 'NaomiPradoHinojosa',
'password' => Hash::make('texto'),
'nombre'   => 'Naomi ',
'apellido' => 'Prado Hinojosa',
'correo'   => 'Naomi.Prado.Hinojosa@gmail.com',
]);

Usuario::create([
'username' => 'OliverVillarroelCaypa',
'password' => Hash::make('texto'),
'nombre'   => 'Oliver ',
'apellido' => 'Villarroel Caypa',
'correo'   => 'Oliver.Villarroel.Caypa@gmail.com',
]);

Usuario::create([
'username' => 'RaulTerrazasGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Raul ',
'apellido' => 'Terrazas Garcia',
'correo'   => 'Raul.Terrazas.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'DiegoJarroRamos',
'password' => Hash::make('texto'),
'nombre'   => 'Diego ',
'apellido' => 'Jarro Ramos',
'correo'   => 'Diego.Jarro.Ramos@gmail.com',
]);

Usuario::create([
'username' => 'ManteBrandomJorrillo',
'password' => Hash::make('texto'),
'nombre'   => 'Mante ',
'apellido' => 'Brandom Jorrillo',
'correo'   => 'Mante.Brandom.Jorrillo@gmail.com',
]);

Usuario::create([
'username' => 'AylenNicoleGarciaM.',
'password' => Hash::make('texto'),
'nombre'   => 'Aylen ',
'apellido' => 'Nicole Garcia M.',
'correo'   => 'Aylen.Nicole.Garcia.M.@gmail.com',
]);

Usuario::create([
'username' => 'CristianAlejandroGrandon',
'password' => Hash::make('texto'),
'nombre'   => 'Cristian ',
'apellido' => 'Alejandro Grandon',
'correo'   => 'Cristian.Alejandro.Grandon@gmail.com',
]);

Usuario::create([
'username' => 'DarwinPajcho',
'password' => Hash::make('texto'),
'nombre'   => 'Darwin ',
'apellido' => 'Pajcho',
'correo'   => 'Darwin.Pajcho@gmail.com',
]);

Usuario::create([
'username' => 'WilfredoNestorMamani',
'password' => Hash::make('texto'),
'nombre'   => 'Wilfredo ',
'apellido' => 'Nestor Mamani',
'correo'   => 'Wilfredo.Nestor.Mamani@gmail.com',
]);

Usuario::create([
'username' => 'JhoselynFrancisSuarezGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Jhoselyn ',
'apellido' => 'Francis Suarez Garcia',
'correo'   => 'Jhoselyn.Francis.Suarez.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'MarcoAndreMontesGarnica',
'password' => Hash::make('texto'),
'nombre'   => 'Marco ',
'apellido' => 'Andre Montes Garnica',
'correo'   => 'Marco.Andre.Montes.Garnica@gmail.com',
]);

Usuario::create([
'username' => 'JuanRodrigoPazTintoya',
'password' => Hash::make('texto'),
'nombre'   => 'Juan ',
'apellido' => 'Rodrigo Paz Tintoya',
'correo'   => 'Juan.Rodrigo.Paz.Tintoya@gmail.com',
]);

Usuario::create([
'username' => 'AbadChambiLeon',
'password' => Hash::make('texto'),
'nombre'   => 'Abad ',
'apellido' => 'Chambi Leon',
'correo'   => 'Abad.Chambi.Leon@gmail.com',
]);

Usuario::create([
'username' => 'AndruQuispeMoya',
'password' => Hash::make('texto'),
'nombre'   => 'Andru ',
'apellido' => 'Quispe Moya',
'correo'   => 'Andru.Quispe.Moya@gmail.com',
]);

Usuario::create([
'username' => 'RolandoBrayanBustillosZubieta',
'password' => Hash::make('texto'),
'nombre'   => 'Rolando ',
'apellido' => 'Brayan Bustillos Zubieta',
'correo'   => 'Rolando.Brayan.Bustillos.Zubieta@gmail.com',
]);

Usuario::create([
'username' => 'CarlosDanielJuchasaraH',
'password' => Hash::make('texto'),
'nombre'   => 'Carlos ',
'apellido' => 'Daniel Juchasara H',
'correo'   => 'Carlos.Daniel.Juchasara.H@gmail.com',
]);

Usuario::create([
'username' => 'CelinaSerrano',
'password' => Hash::make('texto'),
'nombre'   => 'Celina ',
'apellido' => 'Serrano',
'correo'   => 'Celina.Serrano@gmail.com',
]);

Usuario::create([
'username' => 'ChristianDavidSavatierraClaros',
'password' => Hash::make('texto'),
'nombre'   => 'Christian ',
'apellido' => 'David Savatierra Claros',
'correo'   => 'Christian.David.Savatierra.Claros@gmail.com',
]);

Usuario::create([
'username' => 'ChristianGragedaCotrina',
'password' => Hash::make('texto'),
'nombre'   => 'Christian ',
'apellido' => 'Grageda Cotrina',
'correo'   => 'Christian.Grageda.Cotrina@gmail.com',
]);

Usuario::create([
'username' => 'ChristianVieryMolloGonzales',
'password' => Hash::make('texto'),
'nombre'   => 'Christian ',
'apellido' => 'Viery Mollo Gonzales',
'correo'   => 'Christian.Viery.Mollo.Gonzales@gmail.com',
]);

Usuario::create([
'username' => 'DanielaClaros',
'password' => Hash::make('texto'),
'nombre'   => 'Daniela ',
'apellido' => 'Claros',
'correo'   => 'Daniela.Claros@gmail.com',
]);

Usuario::create([
'username' => 'DerizChoqueJimenez',
'password' => Hash::make('texto'),
'nombre'   => 'Deriz ',
'apellido' => 'Choque Jimenez',
'correo'   => 'Deriz.Choque.Jimenez@gmail.com',
]);

Usuario::create([
'username' => 'EdgarFerrufinoGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Edgar ',
'apellido' => 'Ferrufino Garcia',
'correo'   => 'Edgar.Ferrufino.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'EdisonFlores',
'password' => Hash::make('texto'),
'nombre'   => 'Edison ',
'apellido' => 'Flores',
'correo'   => 'Edison.Flores@gmail.com',
]);

Usuario::create([
'username' => 'FernandoJoseDazaYarhui',
'password' => Hash::make('texto'),
'nombre'   => 'Fernando ',
'apellido' => 'Jose Daza Yarhui',
'correo'   => 'Fernando.Jose.Daza.Yarhui@gmail.com',
]);

Usuario::create([
'username' => 'EddyBrandonVeizagaTrive�o',
'password' => Hash::make('texto'),
'nombre'   => 'Eddy ',
'apellido' => 'Brandon Veizaga Trive�o',
'correo'   => 'Eddy.Brandon.Veizaga.Trive�o@gmail.com',
]);

Usuario::create([
'username' => 'GuilbertoRojasAndia',
'password' => Hash::make('texto'),
'nombre'   => 'Guilberto ',
'apellido' => 'Rojas Andia',
'correo'   => 'Guilberto.Rojas.Andia@gmail.com',
]);

Usuario::create([
'username' => 'JhenniferFarjuriSaavedra',
'password' => Hash::make('texto'),
'nombre'   => 'Jhennifer ',
'apellido' => 'Farjuri Saavedra',
'correo'   => 'Jhennifer.Farjuri.Saavedra@gmail.com',
]);

Usuario::create([
'username' => 'JhoyerJoseOca�aTicona',
'password' => Hash::make('texto'),
'nombre'   => 'Jhoyer ',
'apellido' => 'Jose Oca�a Ticona',
'correo'   => 'Jhoyer.Jose.Oca�a.Ticona@gmail.com',
]);

Usuario::create([
'username' => 'JorgeIvanLoboOrtu�o',
'password' => Hash::make('texto'),
'nombre'   => 'Jorge ',
'apellido' => 'Ivan Lobo Ortu�o',
'correo'   => 'Jorge.Ivan.Lobo.Ortu�o@gmail.com',
]);

Usuario::create([
'username' => 'JhonGualbertoRodriguezSanchez',
'password' => Hash::make('texto'),
'nombre'   => 'Jhon ',
'apellido' => 'Gualberto Rodriguez Sanchez',
'correo'   => 'Jhon.Gualberto.Rodriguez.Sanchez@gmail.com',
]);

Usuario::create([
'username' => 'JhosuaGabrielMurilloRocha',
'password' => Hash::make('texto'),
'nombre'   => 'Jhosua ',
'apellido' => 'Gabriel Murillo Rocha',
'correo'   => 'Jhosua.Gabriel.Murillo.Rocha@gmail.com',
]);

Usuario::create([
'username' => 'LuisAntonioCorralesAlbarracin',
'password' => Hash::make('texto'),
'nombre'   => 'Luis ',
'apellido' => 'Antonio Corrales Albarracin',
'correo'   => 'Luis.Antonio.Corrales.Albarracin@gmail.com',
]);

Usuario::create([
'username' => 'MariaElenaBernabeChucueta',
'password' => Hash::make('texto'),
'nombre'   => 'Maria ',
'apellido' => 'Elena Bernabe Chucueta',
'correo'   => 'Maria.Elena.Bernabe.Chucueta@gmail.com',
]);

Usuario::create([
'username' => 'NayderSaavedraVeizaga',
'password' => Hash::make('texto'),
'nombre'   => 'Nayder ',
'apellido' => 'Saavedra Veizaga',
'correo'   => 'Nayder.Saavedra.Veizaga@gmail.com',
]);

Usuario::create([
'username' => 'NoeEspinozaFlores',
'password' => Hash::make('texto'),
'nombre'   => 'Noe ',
'apellido' => 'Espinoza Flores',
'correo'   => 'Noe.Espinoza.Flores@gmail.com',
]);

Usuario::create([
'username' => 'VangeliJairoNumbelaRojas',
'password' => Hash::make('texto'),
'nombre'   => 'Vangeli ',
'apellido' => 'Jairo Numbela Rojas',
'correo'   => 'Vangeli.Jairo.Numbela.Rojas@gmail.com',
]);

Usuario::create([
'username' => 'OscarOrdo�ezPinto',
'password' => Hash::make('texto'),
'nombre'   => 'Oscar ',
'apellido' => 'Ordo�ez Pinto',
'correo'   => 'Oscar.Ordo�ez.Pinto@gmail.com',
]);

Usuario::create([
'username' => 'PolethTordoyaMejia',
'password' => Hash::make('texto'),
'nombre'   => 'Poleth ',
'apellido' => 'Tordoya Mejia',
'correo'   => 'Poleth.Tordoya.Mejia@gmail.com',
]);

Usuario::create([
'username' => 'RaulFerandez',
'password' => Hash::make('texto'),
'nombre'   => 'Raul ',
'apellido' => 'Ferandez',
'correo'   => 'Raul.Ferandez@gmail.com',
]);

Usuario::create([
'username' => 'RolyMontecinosGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Roly ',
'apellido' => 'Montecinos Garcia',
'correo'   => 'Roly.Montecinos.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'SarinaCoriaGutierrez',
'password' => Hash::make('texto'),
'nombre'   => 'Sarina ',
'apellido' => 'Coria Gutierrez',
'correo'   => 'Sarina.Coria.Gutierrez@gmail.com',
]);

Usuario::create([
'username' => 'SofiaDanielaCovarrubias',
'password' => Hash::make('texto'),
'nombre'   => 'Sofia ',
'apellido' => 'Daniela Covarrubias',
'correo'   => 'Sofia.Daniela.Covarrubias@gmail.com',
]);

Usuario::create([
'username' => 'PabloMamaniRojas',
'password' => Hash::make('texto'),
'nombre'   => 'Pablo ',
'apellido' => 'Mamani Rojas',
'correo'   => 'Pablo.Mamani.Rojas@gmail.com',
]);

Usuario::create([
'username' => 'WilliamAlexanderMonta�oLaime',
'password' => Hash::make('texto'),
'nombre'   => 'William ',
'apellido' => 'Alexander Monta�o Laime',
'correo'   => 'William.Alexander.Monta�o.Laime@gmail.com',
]);

Usuario::create([
'username' => 'AlanGiovanniMoraVargas',
'password' => Hash::make('texto'),
'nombre'   => 'Alan ',
'apellido' => 'Giovanni Mora Vargas',
'correo'   => 'Alan.Giovanni.Mora.Vargas@gmail.com',
]);

Usuario::create([
'username' => 'AlexPacaMenes',
'password' => Hash::make('texto'),
'nombre'   => 'Alex ',
'apellido' => 'Paca Menes',
'correo'   => 'Alex.Paca.Menes@gmail.com',
]);

Usuario::create([
'username' => 'AndreAldunateGuzman',
'password' => Hash::make('texto'),
'nombre'   => 'Andre ',
'apellido' => 'Aldunate Guzman',
'correo'   => 'Andre.Aldunate.Guzman@gmail.com',
]);

Usuario::create([
'username' => 'AndresTorrico',
'password' => Hash::make('texto'),
'nombre'   => 'Andres ',
'apellido' => 'Torrico',
'correo'   => 'Andres.Torrico@gmail.com',
]);

Usuario::create([
'username' => 'BeimarArispeArnez',
'password' => Hash::make('texto'),
'nombre'   => 'Beimar ',
'apellido' => 'Arispe Arnez',
'correo'   => 'Beimar.Arispe.Arnez@gmail.com',
]);

Usuario::create([
'username' => 'BeimarCabreraHuanca',
'password' => Hash::make('texto'),
'nombre'   => 'Beimar ',
'apellido' => 'Cabrera Huanca',
'correo'   => 'Beimar.Cabrera.Huanca@gmail.com',
]);

Usuario::create([
'username' => 'BiancaSarahiFernandezQuispe',
'password' => Hash::make('texto'),
'nombre'   => 'Bianca ',
'apellido' => 'Sarahi Fernandez Quispe',
'correo'   => 'Bianca.Sarahi.Fernandez.Quispe@gmail.com',
]);

Usuario::create([
'username' => 'BryanVasquezMaldonado',
'password' => Hash::make('texto'),
'nombre'   => 'Bryan ',
'apellido' => 'Vasquez Maldonado',
'correo'   => 'Bryan.Vasquez.Maldonado@gmail.com',
]);

Usuario::create([
'username' => 'CarlosBrianRevolloVillarroel',
'password' => Hash::make('texto'),
'nombre'   => 'Carlos ',
'apellido' => 'Brian Revollo Villarroel',
'correo'   => 'Carlos.Brian.Revollo.Villarroel@gmail.com',
]);

Usuario::create([
'username' => 'CristianArandoQueca�a',
'password' => Hash::make('texto'),
'nombre'   => 'Cristian ',
'apellido' => 'Arando Queca�a',
'correo'   => 'Cristian.Arando.Queca�a@gmail.com',
]);

Usuario::create([
'username' => 'EmanuelQuispe',
'password' => Hash::make('texto'),
'nombre'   => 'Emanuel ',
'apellido' => 'Quispe',
'correo'   => 'Emanuel.Quispe@gmail.com',
]);

Usuario::create([
'username' => 'EstefanyRedriguezHidalgo',
'password' => Hash::make('texto'),
'nombre'   => 'Estefany ',
'apellido' => 'Redriguez Hidalgo',
'correo'   => 'Estefany.Redriguez.Hidalgo@gmail.com',
]);

Usuario::create([
'username' => 'EvelinElianaSolis',
'password' => Hash::make('texto'),
'nombre'   => 'Evelin ',
'apellido' => 'Eliana Solis',
'correo'   => 'Evelin.Eliana.Solis@gmail.com',
]);

Usuario::create([
'username' => 'EverCocaQuiroz',
'password' => Hash::make('texto'),
'nombre'   => 'Ever ',
'apellido' => 'Coca Quiroz',
'correo'   => 'Ever.Coca.Quiroz@gmail.com',
]);

Usuario::create([
'username' => 'FernandoFlorencioAyaviriGamarra',
'password' => Hash::make('texto'),
'nombre'   => 'Fernando ',
'apellido' => 'Florencio Ayaviri Gamarra',
'correo'   => 'Fernando.Florencio.Ayaviri.Gamarra@gmail.com',
]);

Usuario::create([
'username' => 'FernandoRodrigezMorales',
'password' => Hash::make('texto'),
'nombre'   => 'Fernando ',
'apellido' => 'Rodrigez Morales',
'correo'   => 'Fernando.Rodrigez.Morales@gmail.com',
]);

Usuario::create([
'username' => 'FidelUgarteArratia',
'password' => Hash::make('texto'),
'nombre'   => 'Fidel ',
'apellido' => 'Ugarte Arratia',
'correo'   => 'Fidel.Ugarte.Arratia@gmail.com',
]);

Usuario::create([
'username' => 'FranciscoSantiagoCarvalloLazo',
'password' => Hash::make('texto'),
'nombre'   => 'Francisco ',
'apellido' => 'Santiago Carvallo Lazo',
'correo'   => 'Francisco.Santiago.Carvallo.Lazo@gmail.com',
]);

Usuario::create([
'username' => 'GonzalesYahuilaAlison',
'password' => Hash::make('texto'),
'nombre'   => 'Gonzales ',
'apellido' => 'Yahuila Alison',
'correo'   => 'Gonzales.Yahuila.Alison@gmail.com',
]);

Usuario::create([
'username' => 'IsraelGonzaloOroscoZeballos',
'password' => Hash::make('texto'),
'nombre'   => 'Israel ',
'apellido' => 'Gonzalo Orosco Zeballos',
'correo'   => 'Israel.Gonzalo.Orosco.Zeballos@gmail.com',
]);

Usuario::create([
'username' => 'IsraelRodriguezImpa',
'password' => Hash::make('texto'),
'nombre'   => 'Israel ',
'apellido' => 'Rodriguez Impa',
'correo'   => 'Israel.Rodriguez.Impa@gmail.com',
]);

Usuario::create([
'username' => 'JuanEduardoSaraviaMiranda',
'password' => Hash::make('texto'),
'nombre'   => 'Juan ',
'apellido' => 'Eduardo Saravia Miranda',
'correo'   => 'Juan.Eduardo.Saravia.Miranda@gmail.com',
]);

Usuario::create([
'username' => 'MarceloChoqueCuellar',
'password' => Hash::make('texto'),
'nombre'   => 'Marcelo ',
'apellido' => 'Choque Cuellar',
'correo'   => 'Marcelo.Choque.Cuellar@gmail.com',
]);

Usuario::create([
'username' => 'MauricioRamos',
'password' => Hash::make('texto'),
'nombre'   => 'Mauricio ',
'apellido' => 'Ramos',
'correo'   => 'Mauricio.Ramos@gmail.com',
]);

Usuario::create([
'username' => 'MauricioZabalaga',
'password' => Hash::make('texto'),
'nombre'   => 'Mauricio ',
'apellido' => 'Zabalaga',
'correo'   => 'Mauricio.Zabalaga@gmail.com',
]);

Usuario::create([
'username' => 'NanerPuriMamani',
'password' => Hash::make('texto'),
'nombre'   => 'Naner ',
'apellido' => 'Puri Mamani',
'correo'   => 'Naner.Puri.Mamani@gmail.com',
]);

Usuario::create([
'username' => 'RicardoJavierUdaetaLarrain',
'password' => Hash::make('texto'),
'nombre'   => 'Ricardo ',
'apellido' => 'Javier Udaeta Larrain',
'correo'   => 'Ricardo.Javier.Udaeta.Larrain@gmail.com',
]);

Usuario::create([
'username' => 'SamuelBordaCaballero',
'password' => Hash::make('texto'),
'nombre'   => 'Samuel ',
'apellido' => 'Borda Caballero',
'correo'   => 'Samuel.Borda.Caballero@gmail.com',
]);

Usuario::create([
'username' => 'ShirleyEdithRomeroQuispe',
'password' => Hash::make('texto'),
'nombre'   => 'Shirley ',
'apellido' => 'Edith Romero Quispe',
'correo'   => 'Shirley.Edith.Romero.Quispe@gmail.com',
]);

Usuario::create([
'username' => 'SofiaSilvestreCruz',
'password' => Hash::make('texto'),
'nombre'   => 'Sofia ',
'apellido' => 'Silvestre Cruz',
'correo'   => 'Sofia.Silvestre.Cruz@gmail.com',
]);

Usuario::create([
'username' => 'VanessaEstherFloresMonta�o',
'password' => Hash::make('texto'),
'nombre'   => 'Vanessa ',
'apellido' => 'Esther Flores Monta�o',
'correo'   => 'Vanessa.Esther.Flores.Monta�o@gmail.com',
]);

Usuario::create([
'username' => 'VeimarHinojosaJuan',
'password' => Hash::make('texto'),
'nombre'   => 'Veimar ',
'apellido' => 'Hinojosa Juan',
'correo'   => 'Veimar.Hinojosa.Juan@gmail.com',
]);

Usuario::create([
'username' => 'ViancaMamaniRamos',
'password' => Hash::make('texto'),
'nombre'   => 'Vianca ',
'apellido' => 'Mamani Ramos',
'correo'   => 'Vianca.Mamani.Ramos@gmail.com',
]);

Usuario::create([
'username' => 'WilsonCespedesR.',
'password' => Hash::make('texto'),
'nombre'   => 'Wilson ',
'apellido' => 'Cespedes R.',
'correo'   => 'Wilson.Cespedes.R.@gmail.com',
]);

Usuario::create([
'username' => 'JoshuaGabrielMurilloRocha',
'password' => Hash::make('texto'),
'nombre'   => 'Joshua ',
'apellido' => 'Gabriel Murillo Rocha',
'correo'   => 'Joshua.Gabriel.Murillo.Rocha@gmail.com',
]);

Usuario::create([
'username' => 'AlbertoHuarachi',
'password' => Hash::make('texto'),
'nombre'   => 'Alberto ',
'apellido' => 'Huarachi',
'correo'   => 'Alberto.Huarachi@gmail.com',
]);

Usuario::create([
'username' => 'AlejandroMonta�oCayola',
'password' => Hash::make('texto'),
'nombre'   => 'Alejandro ',
'apellido' => 'Monta�o Cayola',
'correo'   => 'Alejandro.Monta�o.Cayola@gmail.com',
]);

Usuario::create([
'username' => 'AlejandroSejasAlcocer',
'password' => Hash::make('texto'),
'nombre'   => 'Alejandro ',
'apellido' => 'Sejas Alcocer',
'correo'   => 'Alejandro.Sejas.Alcocer@gmail.com',
]);

Usuario::create([
'username' => 'ArturoCamachoMamani',
'password' => Hash::make('texto'),
'nombre'   => 'Arturo ',
'apellido' => 'Camacho Mamani',
'correo'   => 'Arturo.Camacho.Mamani@gmail.com',
]);

Usuario::create([
'username' => 'CamilaAdrianaCespedesVillena',
'password' => Hash::make('texto'),
'nombre'   => 'Camila ',
'apellido' => 'Adriana Cespedes Villena',
'correo'   => 'Camila.Adriana.Cespedes.Villena@gmail.com',
]);

Usuario::create([
'username' => 'CarlosJuniorMangudoBetancur',
'password' => Hash::make('texto'),
'nombre'   => 'Carlos ',
'apellido' => 'Junior Mangudo Betancur',
'correo'   => 'Carlos.Junior.Mangudo.Betancur@gmail.com',
]);

Usuario::create([
'username' => 'CieloCamilaFloresVerastegui',
'password' => Hash::make('texto'),
'nombre'   => 'Cielo ',
'apellido' => 'Camila Flores Verastegui',
'correo'   => 'Cielo.Camila.Flores.Verastegui@gmail.com',
]);

Usuario::create([
'username' => 'DavidCarlosPerezChoque',
'password' => Hash::make('texto'),
'nombre'   => 'David ',
'apellido' => 'Carlos Perez Choque',
'correo'   => 'David.Carlos.Perez.Choque@gmail.com',
]);

Usuario::create([
'username' => 'EileenElizaPacara',
'password' => Hash::make('texto'),
'nombre'   => 'Eileen ',
'apellido' => 'Eliza Pacara',
'correo'   => 'Eileen.Eliza.Pacara@gmail.com',
]);

Usuario::create([
'username' => 'JonathanMonta�o',
'password' => Hash::make('texto'),
'nombre'   => 'Jonathan ',
'apellido' => 'Monta�o',
'correo'   => 'Jonathan.Monta�o@gmail.com',
]);

Usuario::create([
'username' => 'JorgeBorgesReyes',
'password' => Hash::make('texto'),
'nombre'   => 'Jorge ',
'apellido' => 'Borges Reyes',
'correo'   => 'Jorge.Borges.Reyes@gmail.com',
]);

Usuario::create([
'username' => 'JoseCaceresAramayo',
'password' => Hash::make('texto'),
'nombre'   => 'Jose ',
'apellido' => 'Caceres Aramayo',
'correo'   => 'Jose.Caceres.Aramayo@gmail.com',
]);

Usuario::create([
'username' => 'LizbethCayetanoMiranda',
'password' => Hash::make('texto'),
'nombre'   => 'Lizbeth ',
'apellido' => 'Cayetano Miranda',
'correo'   => 'Lizbeth.Cayetano.Miranda@gmail.com',
]);

Usuario::create([
'username' => 'OliverChiriZambrana',
'password' => Hash::make('texto'),
'nombre'   => 'Oliver ',
'apellido' => 'Chiri Zambrana',
'correo'   => 'Oliver.Chiri.Zambrana@gmail.com',
]);

Usuario::create([
'username' => 'SamuelCopaCamacho',
'password' => Hash::make('texto'),
'nombre'   => 'Samuel ',
'apellido' => 'Copa Camacho',
'correo'   => 'Samuel.Copa.Camacho@gmail.com',
]);

Usuario::create([
'username' => 'WendyRodriguezAngulo',
'password' => Hash::make('texto'),
'nombre'   => 'Wendy ',
'apellido' => 'Rodriguez Angulo',
'correo'   => 'Wendy.Rodriguez.Angulo@gmail.com',
]);

Usuario::create([
'username' => 'IsaacBarcoTerrazas',
'password' => Hash::make('texto'),
'nombre'   => 'Isaac ',
'apellido' => 'Barco Terrazas',
'correo'   => 'Isaac.Barco.Terrazas@gmail.com',
]);

Usuario::create([
'username' => 'RoyherAlexanderMeridaG.',
'password' => Hash::make('texto'),
'nombre'   => 'Royher ',
'apellido' => 'Alexander Merida G.',
'correo'   => 'Royher.Alexander.Merida.G.@gmail.com',
]);

Usuario::create([
'username' => 'AdrianLucasMamaniMamani',
'password' => Hash::make('texto'),
'nombre'   => 'Adrian ',
'apellido' => 'Lucas Mamani Mamani',
'correo'   => 'Adrian.Lucas.Mamani.Mamani@gmail.com',
]);

Usuario::create([
'username' => 'AbrahamIllianesFLores',
'password' => Hash::make('texto'),
'nombre'   => 'Abraham ',
'apellido' => 'Illianes FLores',
'correo'   => 'Abraham.Illianes.FLores@gmail.com',
]);

Usuario::create([
'username' => 'AlejandroChavezU',
'password' => Hash::make('texto'),
'nombre'   => 'Alejandro ',
'apellido' => 'Chavez U',
'correo'   => 'Alejandro.Chavez.U@gmail.com',
]);

Usuario::create([
'username' => 'AlejandroPabloCondoUre�a',
'password' => Hash::make('texto'),
'nombre'   => 'Alejandro ',
'apellido' => 'Pablo Condo Ure�a',
'correo'   => 'Alejandro.Pablo.Condo.Ure�a@gmail.com',
]);

Usuario::create([
'username' => 'AlvaroMolinaVillamor',
'password' => Hash::make('texto'),
'nombre'   => 'Alvaro ',
'apellido' => 'Molina Villamor',
'correo'   => 'Alvaro.Molina.Villamor@gmail.com',
]);

Usuario::create([
'username' => 'BrandyRequeCoca',
'password' => Hash::make('texto'),
'nombre'   => 'Brandy ',
'apellido' => 'Reque Coca',
'correo'   => 'Brandy.Reque.Coca@gmail.com',
]);

Usuario::create([
'username' => 'CarolMSejasDelgadillo',
'password' => Hash::make('texto'),
'nombre'   => 'Carol ',
'apellido' => 'M Sejas Delgadillo',
'correo'   => 'Carol.M.Sejas.Delgadillo@gmail.com',
]);

Usuario::create([
'username' => 'ChristianJesusLlanosMendoza',
'password' => Hash::make('texto'),
'nombre'   => 'Christian ',
'apellido' => 'Jesus Llanos Mendoza',
'correo'   => 'Christian.Jesus.Llanos.Mendoza@gmail.com',
]);

Usuario::create([
'username' => 'DeboraMartinezBurgos',
'password' => Hash::make('texto'),
'nombre'   => 'Debora ',
'apellido' => 'Martinez Burgos',
'correo'   => 'Debora.Martinez.Burgos@gmail.com',
]);

Usuario::create([
'username' => 'DennisAdrianPariLimachi',
'password' => Hash::make('texto'),
'nombre'   => 'Dennis ',
'apellido' => 'Adrian Pari Limachi',
'correo'   => 'Dennis.Adrian.Pari.Limachi@gmail.com',
]);

Usuario::create([
'username' => 'DilanAntezana',
'password' => Hash::make('texto'),
'nombre'   => 'Dilan ',
'apellido' => 'Antezana',
'correo'   => 'Dilan.Antezana@gmail.com',
]);

Usuario::create([
'username' => 'FabianPe�arrieta',
'password' => Hash::make('texto'),
'nombre'   => 'Fabian ',
'apellido' => 'Pe�arrieta',
'correo'   => 'Fabian.Pe�arrieta@gmail.com',
]);

Usuario::create([
'username' => 'FernandaAguilarVillalobos',
'password' => Hash::make('texto'),
'nombre'   => 'Fernanda ',
'apellido' => 'Aguilar Villalobos',
'correo'   => 'Fernanda.Aguilar.Villalobos@gmail.com',
]);

Usuario::create([
'username' => 'GabrielaCocaCossio',
'password' => Hash::make('texto'),
'nombre'   => 'Gabriela ',
'apellido' => 'Coca Cossio',
'correo'   => 'Gabriela.Coca.Cossio@gmail.com',
]);

Usuario::create([
'username' => 'GustavoAlanMonta�oArgote',
'password' => Hash::make('texto'),
'nombre'   => 'Gustavo ',
'apellido' => 'Alan Monta�o Argote',
'correo'   => 'Gustavo.Alan.Monta�o.Argote@gmail.com',
]);

Usuario::create([
'username' => 'HaroldNelsonArcosTerrazas',
'password' => Hash::make('texto'),
'nombre'   => 'Harold ',
'apellido' => 'Nelson Arcos Terrazas',
'correo'   => 'Harold.Nelson.Arcos.Terrazas@gmail.com',
]);

Usuario::create([
'username' => 'HerediaAlejandro',
'password' => Hash::make('texto'),
'nombre'   => 'Heredia ',
'apellido' => 'Alejandro',
'correo'   => 'Heredia.Alejandro@gmail.com',
]);

Usuario::create([
'username' => 'JaimeCristianGarciaVino',
'password' => Hash::make('texto'),
'nombre'   => 'Jaime ',
'apellido' => 'Cristian Garcia Vino',
'correo'   => 'Jaime.Cristian.Garcia.Vino@gmail.com',
]);

Usuario::create([
'username' => 'JavierEduardoLlanosGuzman',
'password' => Hash::make('texto'),
'nombre'   => 'Javier ',
'apellido' => 'Eduardo Llanos Guzman',
'correo'   => 'Javier.Eduardo.Llanos.Guzman@gmail.com',
]);

Usuario::create([
'username' => 'JazzedtTiglatMonta�oO',
'password' => Hash::make('texto'),
'nombre'   => 'Jazzedt ',
'apellido' => 'Tiglat Monta�o O',
'correo'   => 'Jazzedt.Tiglat.Monta�o.O@gmail.com',
]);

Usuario::create([
'username' => 'JosueFuentesCuaquira',
'password' => Hash::make('texto'),
'nombre'   => 'Josue ',
'apellido' => 'Fuentes Cuaquira',
'correo'   => 'Josue.Fuentes.Cuaquira@gmail.com',
]);

Usuario::create([
'username' => 'JulioReneCamachoGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Julio ',
'apellido' => 'Rene Camacho Garcia',
'correo'   => 'Julio.Rene.Camacho.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'KevinErickAguilarArispe',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Erick Aguilar Arispe',
'correo'   => 'Kevin.Erick.Aguilar.Arispe@gmail.com',
]);

Usuario::create([
'username' => 'KevinVillanuevaRivas',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Villanueva Rivas',
'correo'   => 'Kevin.Villanueva.Rivas@gmail.com',
]);

Usuario::create([
'username' => 'LuisAlejandroPeresSantos',
'password' => Hash::make('texto'),
'nombre'   => 'Luis ',
'apellido' => 'Alejandro Peres Santos',
'correo'   => 'Luis.Alejandro.Peres.Santos@gmail.com',
]);

Usuario::create([
'username' => 'MariaAndreaPelaezCruz',
'password' => Hash::make('texto'),
'nombre'   => 'Maria ',
'apellido' => 'Andrea Pelaez Cruz',
'correo'   => 'Maria.Andrea.Pelaez.Cruz@gmail.com',
]);

Usuario::create([
'username' => 'MarioAntonioMurilloZeballos',
'password' => Hash::make('texto'),
'nombre'   => 'Mario ',
'apellido' => 'Antonio Murillo Zeballos',
'correo'   => 'Mario.Antonio.Murillo.Zeballos@gmail.com',
]);

Usuario::create([
'username' => 'MiguelAngelVillcaMinaya',
'password' => Hash::make('texto'),
'nombre'   => 'Miguel ',
'apellido' => 'Angel Villca Minaya',
'correo'   => 'Miguel.Angel.Villca.Minaya@gmail.com',
]);

Usuario::create([
'username' => 'MiguelTomasAguilarSaravia',
'password' => Hash::make('texto'),
'nombre'   => 'Miguel ',
'apellido' => 'Tomas Aguilar Saravia',
'correo'   => 'Miguel.Tomas.Aguilar.Saravia@gmail.com',
]);

Usuario::create([
'username' => 'NicoleMelaniaCruzGonzales',
'password' => Hash::make('texto'),
'nombre'   => 'Nicole ',
'apellido' => 'Melania Cruz Gonzales',
'correo'   => 'Nicole.Melania.Cruz.Gonzales@gmail.com',
]);

Usuario::create([
'username' => 'RomarioRamosRamirez',
'password' => Hash::make('texto'),
'nombre'   => 'Romario ',
'apellido' => 'Ramos Ramirez',
'correo'   => 'Romario.Ramos.Ramirez@gmail.com',
]);

Usuario::create([
'username' => 'DiegoFernandoPerezLuna',
'password' => Hash::make('texto'),
'nombre'   => 'Diego ',
'apellido' => 'Fernando Perez Luna',
'correo'   => 'Diego.Fernando.Perez.Luna@gmail.com',
]);

Usuario::create([
'username' => 'AlejandraDiegoSaavedraArteaga',
'password' => Hash::make('texto'),
'nombre'   => 'Alejandra ',
'apellido' => 'Diego Saavedra Arteaga',
'correo'   => 'Alejandra.Diego.Saavedra.Arteaga@gmail.com',
]);

Usuario::create([
'username' => 'AlfonsoMercadoV.',
'password' => Hash::make('texto'),
'nombre'   => 'Alfonso ',
'apellido' => 'Mercado V.',
'correo'   => 'Alfonso.Mercado.V.@gmail.com',
]);

Usuario::create([
'username' => 'BrianArmandoSuarezAgerra',
'password' => Hash::make('texto'),
'nombre'   => 'Brian ',
'apellido' => 'Armando Suarez Agerra',
'correo'   => 'Brian.Armando.Suarez.Agerra@gmail.com',
]);

Usuario::create([
'username' => 'CarolayVeraBorda',
'password' => Hash::make('texto'),
'nombre'   => 'Carolay ',
'apellido' => 'Vera Borda',
'correo'   => 'Carolay.Vera.Borda@gmail.com',
]);

Usuario::create([
'username' => 'CristopherApazaCArballo',
'password' => Hash::make('texto'),
'nombre'   => 'Cristopher ',
'apellido' => 'Apaza CArballo',
'correo'   => 'Cristopher.Apaza.CArballo@gmail.com',
]);

Usuario::create([
'username' => 'DarwinGarciaArebalo',
'password' => Hash::make('texto'),
'nombre'   => 'Darwin ',
'apellido' => 'Garcia Arebalo',
'correo'   => 'Darwin.Garcia.Arebalo@gmail.com',
]);

Usuario::create([
'username' => 'DavidEstebanOrellanaGutierrez',
'password' => Hash::make('texto'),
'nombre'   => 'David ',
'apellido' => 'Esteban Orellana Gutierrez',
'correo'   => 'David.Esteban.Orellana.Gutierrez@gmail.com',
]);

Usuario::create([
'username' => 'DilanAndresVelardeArispe',
'password' => Hash::make('texto'),
'nombre'   => 'Dilan ',
'apellido' => 'Andres Velarde Arispe',
'correo'   => 'Dilan.Andres.Velarde.Arispe@gmail.com',
]);

Usuario::create([
'username' => 'EliasCanaviriChoquevillea',
'password' => Hash::make('texto'),
'nombre'   => 'Elias ',
'apellido' => 'Canaviri Choquevillea',
'correo'   => 'Elias.Canaviri.Choquevillea@gmail.com',
]);

Usuario::create([
'username' => 'ErickAlejandroQuirozGil',
'password' => Hash::make('texto'),
'nombre'   => 'Erick ',
'apellido' => 'Alejandro Quiroz Gil',
'correo'   => 'Erick.Alejandro.Quiroz.Gil@gmail.com',
]);

Usuario::create([
'username' => 'ErickaEmilyCamachoGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Ericka ',
'apellido' => 'Emily Camacho Garcia',
'correo'   => 'Ericka.Emily.Camacho.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'EverthRodolfoCopaAldaba',
'password' => Hash::make('texto'),
'nombre'   => 'Everth ',
'apellido' => 'Rodolfo Copa Aldaba',
'correo'   => 'Everth.Rodolfo.Copa.Aldaba@gmail.com',
]);

Usuario::create([
'username' => 'FernandoCalleGonzales',
'password' => Hash::make('texto'),
'nombre'   => 'Fernando ',
'apellido' => 'Calle Gonzales',
'correo'   => 'Fernando.Calle.Gonzales@gmail.com',
]);

Usuario::create([
'username' => 'GladysBoriazHuizo',
'password' => Hash::make('texto'),
'nombre'   => 'Gladys ',
'apellido' => 'Boriaz Huizo',
'correo'   => 'Gladys.Boriaz.Huizo@gmail.com',
]);

Usuario::create([
'username' => 'IvelizAlexandraAyalaLopez',
'password' => Hash::make('texto'),
'nombre'   => 'Iveliz ',
'apellido' => 'Alexandra Ayala Lopez',
'correo'   => 'Iveliz.Alexandra.Ayala.Lopez@gmail.com',
]);

Usuario::create([
'username' => 'JavierVicenteGarciaPadilla',
'password' => Hash::make('texto'),
'nombre'   => 'Javier ',
'apellido' => 'Vicente Garcia Padilla',
'correo'   => 'Javier.Vicente.Garcia.Padilla@gmail.com',
]);

Usuario::create([
'username' => 'JoaoCarpioRocha',
'password' => Hash::make('texto'),
'nombre'   => 'Joao ',
'apellido' => 'Carpio Rocha',
'correo'   => 'Joao.Carpio.Rocha@gmail.com',
]);

Usuario::create([
'username' => 'JoseArmandoMenecesSoliz',
'password' => Hash::make('texto'),
'nombre'   => 'Jose ',
'apellido' => 'Armando Meneces Soliz',
'correo'   => 'Jose.Armando.Meneces.Soliz@gmail.com',
]);

Usuario::create([
'username' => 'JoseMauriciodelCastilloValdivia',
'password' => Hash::make('texto'),
'nombre'   => 'Jose ',
'apellido' => 'Mauricio del Castillo Valdivia',
'correo'   => 'Jose.Mauricio.del.Castillo.Valdivia@gmail.com',
]);

Usuario::create([
'username' => 'KatherineZambranaContreras',
'password' => Hash::make('texto'),
'nombre'   => 'Katherine ',
'apellido' => 'Zambrana Contreras',
'correo'   => 'Katherine.Zambrana.Contreras@gmail.com',
]);

Usuario::create([
'username' => 'KatrinaDamoraAlbortaDelgado',
'password' => Hash::make('texto'),
'nombre'   => 'Katrina ',
'apellido' => 'Damora Alborta Delgado',
'correo'   => 'Katrina.Damora.Alborta.Delgado@gmail.com',
]);

Usuario::create([
'username' => 'KevinRodrigoPeraltaAjiloa',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Rodrigo Peralta Ajiloa',
'correo'   => 'Kevin.Rodrigo.Peralta.Ajiloa@gmail.com',
]);

Usuario::create([
'username' => 'LimbertAlconzTapia',
'password' => Hash::make('texto'),
'nombre'   => 'Limbert ',
'apellido' => 'Alconz Tapia',
'correo'   => 'Limbert.Alconz.Tapia@gmail.com',
]);

Usuario::create([
'username' => 'LuiyardMarceloClarosPereyra',
'password' => Hash::make('texto'),
'nombre'   => 'Luiyard ',
'apellido' => 'Marcelo Claros Pereyra',
'correo'   => 'Luiyard.Marcelo.Claros.Pereyra@gmail.com',
]);

Usuario::create([
'username' => 'OscarAndreRodriguez',
'password' => Hash::make('texto'),
'nombre'   => 'Oscar ',
'apellido' => 'Andre Rodriguez',
'correo'   => 'Oscar.Andre.Rodriguez@gmail.com',
]);

Usuario::create([
'username' => 'ParraSuza�oLeslyMelina',
'password' => Hash::make('texto'),
'nombre'   => 'Parra ',
'apellido' => 'Suza�o Lesly Melina',
'correo'   => 'Parra.Suza�o.Lesly.Melina@gmail.com',
]);

Usuario::create([
'username' => 'RicardoGongoraVasquez',
'password' => Hash::make('texto'),
'nombre'   => 'Ricardo ',
'apellido' => 'Gongora Vasquez',
'correo'   => 'Ricardo.Gongora.Vasquez@gmail.com',
]);

Usuario::create([
'username' => 'RodriguezGuarayoJessica',
'password' => Hash::make('texto'),
'nombre'   => 'Rodriguez ',
'apellido' => 'Guarayo Jessica',
'correo'   => 'Rodriguez.Guarayo.Jessica@gmail.com',
]);

Usuario::create([
'username' => 'SelenaSantaCruz',
'password' => Hash::make('texto'),
'nombre'   => 'Selena ',
'apellido' => 'Santa Cruz',
'correo'   => 'Selena.Santa.Cruz@gmail.com',
]);

Usuario::create([
'username' => 'ValeriaAdrianaCabreraChavarria',
'password' => Hash::make('texto'),
'nombre'   => 'Valeria ',
'apellido' => 'Adriana Cabrera Chavarria',
'correo'   => 'Valeria.Adriana.Cabrera.Chavarria@gmail.com',
]);

Usuario::create([
'username' => 'VilmerVillarroelSanchez',
'password' => Hash::make('texto'),
'nombre'   => 'Vilmer ',
'apellido' => 'Villarroel Sanchez',
'correo'   => 'Vilmer.Villarroel.Sanchez@gmail.com',
]);

Usuario::create([
'username' => 'IsmaelHuarachiTicacolque',
'password' => Hash::make('texto'),
'nombre'   => 'Ismael ',
'apellido' => 'Huarachi Ticacolque',
'correo'   => 'Ismael.Huarachi.Ticacolque@gmail.com',
]);

Usuario::create([
'username' => 'AdrianCamaraReque',
'password' => Hash::make('texto'),
'nombre'   => 'Adrian ',
'apellido' => 'Camara Reque',
'correo'   => 'Adrian.Camara.Reque@gmail.com',
]);

Usuario::create([
'username' => 'AndresGarciaQuispe',
'password' => Hash::make('texto'),
'nombre'   => 'Andres ',
'apellido' => 'Garcia Quispe',
'correo'   => 'Andres.Garcia.Quispe@gmail.com',
]);

Usuario::create([
'username' => 'AndresMatiasAlvarezNu�ez',
'password' => Hash::make('texto'),
'nombre'   => 'Andres ',
'apellido' => 'Matias Alvarez Nu�ez',
'correo'   => 'Andres.Matias.Alvarez.Nu�ez@gmail.com',
]);

Usuario::create([
'username' => 'AnwarEcheveriaBaldivieso',
'password' => Hash::make('texto'),
'nombre'   => 'Anwar ',
'apellido' => 'Echeveria Baldivieso',
'correo'   => 'Anwar.Echeveria.Baldivieso@gmail.com',
]);

Usuario::create([
'username' => 'ChristianManuelCamachoS.',
'password' => Hash::make('texto'),
'nombre'   => 'Christian ',
'apellido' => 'Manuel Camacho S.',
'correo'   => 'Christian.Manuel.Camacho.S.@gmail.com',
]);

Usuario::create([
'username' => 'CristianMoreiraFlores',
'password' => Hash::make('texto'),
'nombre'   => 'Cristian ',
'apellido' => 'Moreira Flores',
'correo'   => 'Cristian.Moreira.Flores@gmail.com',
]);

Usuario::create([
'username' => 'CristianRojasVeizaga',
'password' => Hash::make('texto'),
'nombre'   => 'Cristian ',
'apellido' => 'Rojas Veizaga',
'correo'   => 'Cristian.Rojas.Veizaga@gmail.com',
]);

Usuario::create([
'username' => 'DavidArcayneLoza',
'password' => Hash::make('texto'),
'nombre'   => 'David ',
'apellido' => 'Arcayne Loza',
'correo'   => 'David.Arcayne.Loza@gmail.com',
]);

Usuario::create([
'username' => 'DavidBorrazSantos',
'password' => Hash::make('texto'),
'nombre'   => 'David ',
'apellido' => 'Borraz Santos',
'correo'   => 'David.Borraz.Santos@gmail.com',
]);

Usuario::create([
'username' => 'DylanCespedesBenavides',
'password' => Hash::make('texto'),
'nombre'   => 'Dylan ',
'apellido' => 'Cespedes Benavides',
'correo'   => 'Dylan.Cespedes.Benavides@gmail.com',
]);

Usuario::create([
'username' => 'DonatoJustinianoChoqueChoque',
'password' => Hash::make('texto'),
'nombre'   => 'Donato ',
'apellido' => 'Justiniano Choque Choque',
'correo'   => 'Donato.Justiniano.Choque.Choque@gmail.com',
]);

Usuario::create([
'username' => 'ErickAlejadroQuirozGil',
'password' => Hash::make('texto'),
'nombre'   => 'Erick ',
'apellido' => 'Alejadro Quiroz Gil',
'correo'   => 'Erick.Alejadro.Quiroz.Gil@gmail.com',
]);

Usuario::create([
'username' => 'EddyQuispeRodriguez',
'password' => Hash::make('texto'),
'nombre'   => 'Eddy ',
'apellido' => 'Quispe Rodriguez',
'correo'   => 'Eddy.Quispe.Rodriguez@gmail.com',
]);

Usuario::create([
'username' => 'GiselleGarciaSoliz',
'password' => Hash::make('texto'),
'nombre'   => 'Giselle ',
'apellido' => 'Garcia Soliz',
'correo'   => 'Giselle.Garcia.Soliz@gmail.com',
]);

Usuario::create([
'username' => 'HugoFernandoCariCazas',
'password' => Hash::make('texto'),
'nombre'   => 'Hugo ',
'apellido' => 'Fernando Cari Cazas',
'correo'   => 'Hugo.Fernando.Cari.Cazas@gmail.com',
]);

Usuario::create([
'username' => 'JavierFiligrana',
'password' => Hash::make('texto'),
'nombre'   => 'Javier ',
'apellido' => 'Filigrana',
'correo'   => 'Javier.Filigrana@gmail.com',
]);

Usuario::create([
'username' => 'JesicaVanesaBordaMorales',
'password' => Hash::make('texto'),
'nombre'   => 'Jesica ',
'apellido' => 'Vanesa Borda Morales',
'correo'   => 'Jesica.Vanesa.Borda.Morales@gmail.com',
]);

Usuario::create([
'username' => 'JhulyKelyCeballosCepeda',
'password' => Hash::make('texto'),
'nombre'   => 'Jhuly ',
'apellido' => 'Kely Ceballos Cepeda',
'correo'   => 'Jhuly.Kely.Ceballos.Cepeda@gmail.com',
]);

Usuario::create([
'username' => 'JhonatanAlaZurita',
'password' => Hash::make('texto'),
'nombre'   => 'Jhonatan ',
'apellido' => 'Ala Zurita',
'correo'   => 'Jhonatan.Ala.Zurita@gmail.com',
]);

Usuario::create([
'username' => 'JuanDeybiGamboaMarca',
'password' => Hash::make('texto'),
'nombre'   => 'Juan ',
'apellido' => 'Deybi Gamboa Marca',
'correo'   => 'Juan.Deybi.Gamboa.Marca@gmail.com',
]);

Usuario::create([
'username' => 'JulioCesarPayaArgote',
'password' => Hash::make('texto'),
'nombre'   => 'Julio ',
'apellido' => 'Cesar Paya Argote',
'correo'   => 'Julio.Cesar.Paya.Argote@gmail.com',
]);

Usuario::create([
'username' => 'kevinJandersonOrellanaPanozo',
'password' => Hash::make('texto'),
'nombre'   => 'kevin ',
'apellido' => 'Janderson Orellana Panozo',
'correo'   => 'kevin.Janderson.Orellana.Panozo@gmail.com',
]);

Usuario::create([
'username' => 'LeonelVelezFerrel',
'password' => Hash::make('texto'),
'nombre'   => 'Leonel ',
'apellido' => 'Velez Ferrel',
'correo'   => 'Leonel.Velez.Ferrel@gmail.com',
]);

Usuario::create([
'username' => 'SoledadNataliaMoralesCallejas',
'password' => Hash::make('texto'),
'nombre'   => 'Soledad ',
'apellido' => 'Natalia Morales Callejas',
'correo'   => 'Soledad.Natalia.Morales.Callejas@gmail.com',
]);

Usuario::create([
'username' => 'NathalyGarcia',
'password' => Hash::make('texto'),
'nombre'   => 'Nathaly ',
'apellido' => 'Garcia',
'correo'   => 'Nathaly.Garcia@gmail.com',
]);

Usuario::create([
'username' => 'NelsonJavierCruzMonta�o',
'password' => Hash::make('texto'),
'nombre'   => 'Nelson ',
'apellido' => 'Javier Cruz Monta�o',
'correo'   => 'Nelson.Javier.Cruz.Monta�o@gmail.com',
]);

Usuario::create([
'username' => 'RodrigoAguachallaCossio',
'password' => Hash::make('texto'),
'nombre'   => 'Rodrigo ',
'apellido' => 'Aguachalla Cossio',
'correo'   => 'Rodrigo.Aguachalla.Cossio@gmail.com',
]);

Usuario::create([
'username' => 'SamuelAlexMonta�oFernandez',
'password' => Hash::make('texto'),
'nombre'   => 'Samuel ',
'apellido' => 'Alex Monta�o Fernandez',
'correo'   => 'Samuel.Alex.Monta�o.Fernandez@gmail.com',
]);

Usuario::create([
'username' => 'SergioVeizagaMu�oz',
'password' => Hash::make('texto'),
'nombre'   => 'Sergio ',
'apellido' => 'Veizaga Mu�oz',
'correo'   => 'Sergio.Veizaga.Mu�oz@gmail.com',
]);

Usuario::create([
'username' => 'TonniEdzonTorrezCruz',
'password' => Hash::make('texto'),
'nombre'   => 'Tonni ',
'apellido' => 'Edzon Torrez Cruz',
'correo'   => 'Tonni.Edzon.Torrez.Cruz@gmail.com',
]);

Usuario::create([
'username' => 'WendiAlvarezDavila',
'password' => Hash::make('texto'),
'nombre'   => 'Wendi ',
'apellido' => 'Alvarez Davila',
'correo'   => 'Wendi.Alvarez.Davila@gmail.com',
]);

Usuario::create([
'username' => 'JosiasLeonardoYujoCuellar',
'password' => Hash::make('texto'),
'nombre'   => 'Josias ',
'apellido' => 'Leonardo Yujo Cuellar',
'correo'   => 'Josias.Leonardo.Yujo.Cuellar@gmail.com',
]);

Usuario::create([
'username' => 'AlanBrunoMaedaChoque',
'password' => Hash::make('texto'),
'nombre'   => 'Alan ',
'apellido' => 'Bruno Maeda Choque',
'correo'   => 'Alan.Bruno.Maeda.Choque@gmail.com',
]);

Usuario::create([
'username' => 'KevinMamaniVargas',
'password' => Hash::make('texto'),
'nombre'   => 'Kevin ',
'apellido' => 'Mamani Vargas',
'correo'   => 'Kevin.Mamani.Vargas@gmail.com',
]);

