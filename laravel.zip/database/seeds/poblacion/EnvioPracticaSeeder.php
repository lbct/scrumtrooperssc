<?php use App\Models\EnvioPractica;
EnvioPractica::create([
'sesion_estudiante_id'  => 1,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 5,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 6,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 7,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 8,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 9,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 10,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 11,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 12,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 13,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 14,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 15,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 16,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 18,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 19,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 20,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 21,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 22,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 23,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 24,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 25,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 26,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 27,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 28,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 29,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 30,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 31,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 33,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 34,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 35,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 46,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 48,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 49,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 50,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 51,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 52,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 53,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 54,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 55,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 56,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 57,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 58,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 59,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 60,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 63,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 64,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 65,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 66,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 76,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 78,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 79,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 80,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 82,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 83,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 84,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 85,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 86,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 87,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 88,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 89,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 91,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 93,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 94,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 95,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 96,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 97,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 98,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 99,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 100,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 101,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 102,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 103,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 104,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 105,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 106,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 108,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 109,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 110,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 111,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 112,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 113,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 114,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 115,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 116,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 117,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 118,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 119,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 120,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 121,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 123,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 124,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 125,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 126,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 127,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 128,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 129,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 130,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 131,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 132,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 133,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 134,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 135,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 136,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 138,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 139,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 140,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 141,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 143,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 144,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 145,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 146,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 148,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 150,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 166,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 168,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 169,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 170,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 171,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 172,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 173,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 174,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 175,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 176,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 177,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 178,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 179,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 180,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 181,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 183,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 184,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 185,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 186,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 187,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 188,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 189,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 190,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 191,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 192,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 193,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 194,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 195,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 196,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 198,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 199,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 200,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 211,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 213,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 214,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 215,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 217,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 218,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 221,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 226,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 228,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 230,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 231,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 232,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 233,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 234,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 236,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 241,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 243,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 244,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 245,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 246,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 247,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 248,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 249,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 250,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 251,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 252,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 253,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 254,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 256,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 258,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 259,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 261,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 262,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 263,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 271,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 273,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 274,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 275,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 276,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 277,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 278,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 279,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 280,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 281,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 282,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 283,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 284,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 285,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 286,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 288,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 289,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 290,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 291,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 292,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 293,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 294,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 295,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 296,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 297,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 298,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 299,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 300,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 301,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 303,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 304,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 306,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 307,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 308,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 309,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 310,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 311,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 312,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 313,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 314,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 315,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 316,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 318,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 319,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 320,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 321,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 322,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 323,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 324,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 325,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 326,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 327,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 328,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 329,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 330,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 331,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 333,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 334,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 335,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 336,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 337,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 338,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 346,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 348,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 349,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 350,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 361,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 363,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 364,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 365,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 366,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 367,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 368,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 369,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 370,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 371,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 372,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 373,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 374,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 375,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 376,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 378,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 379,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 380,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 381,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 382,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 383,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 384,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 385,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 386,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 387,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 388,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 389,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 390,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 391,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 393,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 394,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 395,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 396,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 397,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 398,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 399,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 400,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 401,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 402,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 403,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 404,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 405,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 406,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 408,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 421,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 423,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 424,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 425,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 426,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 427,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 428,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 429,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 430,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 431,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 432,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 433,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 434,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 435,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 436,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 438,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 439,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 440,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 441,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 442,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 443,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 444,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 445,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 446,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 447,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 448,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 449,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 450,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 451,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 453,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 455,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 456,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 457,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 458,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 459,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 466,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 468,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 470,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 471,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 472,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 473,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 474,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 475,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 476,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 477,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 478,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 479,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 480,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 481,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 483,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 484,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 485,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 487,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 488,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 489,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 490,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 491,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 492,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 493,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 494,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 495,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 496,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 498,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 499,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 500,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 501,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 502,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 503,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 504,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 505,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 506,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 507,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 508,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 509,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 510,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 511,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 513,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 514,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 515,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 516,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 517,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 518,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 519,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 520,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 521,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 522,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 523,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 532,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 537,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 538,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 539,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 540,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 541,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 543,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 544,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 545,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 546,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 547,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 548,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 549,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 550,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 551,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 552,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 553,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 554,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 555,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 556,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 558,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 571,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 573,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 574,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 575,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 576,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 577,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 578,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 579,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 601,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 603,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 604,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 605,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 606,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 607,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 608,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 612,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 613,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 616,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 618,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 619,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 620,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 622,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 623,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 646,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 648,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 649,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 650,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 651,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 652,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 653,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 654,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 655,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 656,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 657,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 658,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 659,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 660,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 661,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 664,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 665,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 666,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 667,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 668,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 669,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 670,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 671,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 672,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 673,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 675,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 676,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 678,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 679,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 680,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 681,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 682,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 683,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 684,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 685,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 686,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 688,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 691,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 693,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 694,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 695,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 696,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 697,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 698,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 699,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 706,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 708,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 709,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 710,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 712,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 713,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 714,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 715,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 716,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 717,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 718,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 719,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 720,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 721,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 724,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 725,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 736,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 738,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 739,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 740,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 741,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 742,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 743,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 744,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 745,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 746,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 747,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 748,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 749,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 750,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 751,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 754,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 755,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 756,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 759,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 766,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 768,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 769,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 770,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 772,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 773,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 774,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 775,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 776,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 777,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 778,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 780,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 781,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 783,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 784,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 786,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 787,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 788,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 789,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 791,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 792,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 796,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 798,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 799,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 800,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 801,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 802,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 803,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 805,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 807,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 811,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 813,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 814,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 815,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 816,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 817,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 818,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 819,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 820,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 821,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 822,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 823,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 824,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 825,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 826,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 828,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 829,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 831,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 833,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 836,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 838,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 840,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 841,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 843,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 844,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 845,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 846,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 847,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 848,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 849,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 850,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 851,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 852,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 853,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 854,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 855,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 856,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 858,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 859,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 860,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 861,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 862,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 863,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 864,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 865,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 866,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 867,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 868,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 869,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 870,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 871,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 873,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 874,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 875,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 876,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 877,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 878,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 879,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 880,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 881,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 882,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 883,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 885,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 886,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 888,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 890,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 892,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 893,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 901,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 903,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 904,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 905,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 906,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 907,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 908,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 909,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 910,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 911,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 912,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 916,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 918,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 919,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 920,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 921,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 922,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 923,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 924,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 925,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 926,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 927,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 931,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 933,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 934,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 935,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 936,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 937,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 938,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 939,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 940,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 941,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 942,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 943,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 944,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 945,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 961,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 963,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 964,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 965,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 966,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 968,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 969,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 970,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 971,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 972,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 973,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 974,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 975,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 976,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 978,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 979,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 980,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 981,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 982,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 984,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 986,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 993,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 994,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 995,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 998,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 999,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1000,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1001,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1002,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1005,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1006,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1008,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1009,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1010,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1021,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1023,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1024,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1026,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1027,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1028,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1029,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1030,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1031,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1036,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1038,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1039,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1040,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1041,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1042,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1043,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1044,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1046,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1051,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1053,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1054,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1055,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1056,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1057,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1058,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1059,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1060,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1061,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1062,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1063,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1066,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1068,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1069,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1070,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1071,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1072,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1073,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1074,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1075,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1076,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1077,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1078,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1079,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1080,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1081,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1083,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1084,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1085,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1086,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1087,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1088,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1089,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1090,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1091,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1092,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1093,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1094,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1095,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1096,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1098,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1099,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1100,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1102,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1103,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1104,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1106,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1107,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1108,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1109,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1111,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1115,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1126,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1128,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1129,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1130,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1131,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1132,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1133,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1134,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1135,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1136,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1137,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1138,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1139,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1140,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1141,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1143,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1145,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1146,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1147,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1148,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1149,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1150,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1151,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1156,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1158,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1159,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1160,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1161,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1162,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1163,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1164,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1165,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1166,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1167,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1168,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1169,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1170,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1171,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1173,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1174,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1175,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1176,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1177,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1178,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1179,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1180,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1181,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1182,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1184,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1185,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1186,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1188,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1189,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1190,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1191,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1192,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1193,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1194,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1195,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1196,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1197,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1198,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1199,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1200,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1201,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1203,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1205,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1206,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1208,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1209,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1210,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1216,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1218,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1219,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1220,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1221,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1222,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1223,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1224,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1225,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1226,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1227,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1228,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1231,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1246,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1248,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1249,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1250,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1261,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1263,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1264,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1265,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1266,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1267,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1268,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1269,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1270,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1271,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1272,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1273,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1274,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1275,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1276,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1278,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1279,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1280,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1281,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1282,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1283,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1284,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1285,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1286,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1287,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1288,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1289,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1290,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1291,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1293,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1295,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1306,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1308,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1309,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1310,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1311,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1312,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1313,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1314,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1315,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1317,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1321,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1323,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1324,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1325,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1327,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1330,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1331,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1332,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1333,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1334,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1336,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1351,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1353,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1356,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1357,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1358,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1366,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1368,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1369,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1370,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1371,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1372,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1373,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1381,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1383,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1384,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1396,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1398,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1399,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1400,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1401,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1402,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1403,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1404,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1405,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1406,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1411,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1430,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1432,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1433,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1434,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1435,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1436,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1437,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1438,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1440,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1441,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1443,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1444,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1446,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1447,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1448,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1449,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1450,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1451,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1452,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1453,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1454,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1455,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1459,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1460,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1461,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1462,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1463,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1464,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1465,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1474,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1475,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1476,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1477,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1478,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1479,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1480,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1488,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1489,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1501,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1503,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1504,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1505,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1506,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1507,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1508,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1509,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1510,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1511,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1512,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1513,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1514,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1515,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1516,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1518,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1527,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1531,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1533,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1534,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1535,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1536,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1537,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1538,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1539,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1540,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1543,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1546,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1556,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1561,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1563,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1564,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1565,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1566,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1567,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1568,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1569,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1570,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1571,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1572,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1573,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1576,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1578,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1579,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1580,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1582,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1583,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1586,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1593,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1594,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1595,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1596,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1597,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1598,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1600,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1602,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1606,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1608,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1609,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1610,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1612,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1613,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1614,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1615,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1616,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1617,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1618,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1619,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1620,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1621,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1624,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1625,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1626,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1627,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1628,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1629,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1630,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1631,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1632,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1633,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1635,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1636,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1638,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1639,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1641,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1642,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1644,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1645,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1646,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1648,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1651,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1653,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1654,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1655,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1656,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1657,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1658,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1659,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1666,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1668,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1670,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1671,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1672,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1673,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1674,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1675,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1676,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1677,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1678,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1679,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1680,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1681,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1684,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1685,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1698,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1699,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1700,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1701,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1702,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1703,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1704,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1705,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1706,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1707,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1708,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1709,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1710,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1711,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1714,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1715,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1716,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1719,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1726,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1728,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1730,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1732,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1733,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1734,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1735,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1736,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1737,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1738,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1740,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1741,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1743,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1744,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1746,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1747,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1748,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1749,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1751,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1752,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1756,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1758,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1759,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1760,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1761,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1762,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1763,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1765,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1767,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1773,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1775,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1776,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1777,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1778,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1779,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1780,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1781,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1782,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1783,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1784,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1785,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1786,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1788,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1789,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1791,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1793,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1796,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1798,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1800,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1801,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1803,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1804,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1805,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1806,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1807,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1808,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1809,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1810,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1811,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1812,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1814,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1815,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1816,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1818,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1819,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1820,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1821,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1822,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1824,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1825,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1826,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1827,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1829,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1830,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1831,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1833,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1834,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1835,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1836,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1837,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1838,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1839,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1840,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1842,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1843,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1845,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1846,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1848,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1850,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1852,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1853,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1855,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1863,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1864,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1865,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1866,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1867,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1868,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1869,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1870,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1871,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1872,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1876,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1878,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1879,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1880,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1881,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1882,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1883,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1884,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1885,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1886,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1887,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1891,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1893,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1894,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1895,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1896,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1897,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1899,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1900,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1901,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1902,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1903,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1904,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1905,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1906,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1908,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1910,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1911,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1912,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1913,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1914,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1915,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1921,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1923,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1924,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1925,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1926,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1927,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1928,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1929,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1930,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1931,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1932,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1933,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1934,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1935,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1938,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1939,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1940,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1941,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1942,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1944,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1946,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1951,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1953,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1954,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1955,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1957,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1958,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1959,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1960,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1961,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1962,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1965,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1966,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1968,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1969,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1970,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1971,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1972,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1974,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1975,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1976,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1978,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1979,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1981,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1983,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1984,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1985,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1986,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1987,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1988,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1989,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1990,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1991,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1992,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1993,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1995,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1996,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1997,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1998,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 1999,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2000,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2001,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2002,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2003,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2004,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2006,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2007,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2008,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2009,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2011,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2012,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2013,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2014,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2015,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2016,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2017,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2018,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2019,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2021,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2022,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2023,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2024,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2025,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2026,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2027,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2028,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2029,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2030,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2031,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2032,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2033,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2034,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2036,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2038,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2039,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2040,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2041,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2042,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2043,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2044,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2046,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2047,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2048,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2056,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2057,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2058,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2059,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2061,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2063,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2064,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2066,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2067,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2068,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2069,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2070,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2071,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2072,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2073,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2074,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2075,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2076,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2077,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2078,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2079,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2081,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2082,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2084,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2086,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2087,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2088,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2089,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2090,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2091,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2092,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2093,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2094,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2096,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2097,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2098,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2100,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2101,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2102,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2116,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2117,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2118,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2119,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2120,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2121,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2122,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2123,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2124,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2126,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2128,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2129,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2130,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2131,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2132,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2133,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2134,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2135,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2136,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2137,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2138,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2139,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2141,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2142,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2143,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2144,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2145,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2147,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2148,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2149,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2151,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2152,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2156,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2161,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2162,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2163,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2164,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2165,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2166,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2176,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2177,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2179,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2180,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2181,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2182,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2183,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2184,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2186,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2187,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2188,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2189,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2190,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2191,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2192,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2193,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2206,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2207,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2208,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2209,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2210,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2211,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2212,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2213,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2214,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2216,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2218,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2221,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2222,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2223,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2224,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2225,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2226,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2227,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2228,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2236,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2237,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2238,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2240,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2241,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2242,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2244,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2246,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2247,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2248,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2249,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2251,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2252,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2253,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2254,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2255,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2256,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2257,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2258,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2259,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2266,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2267,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2268,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2269,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2270,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2271,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2272,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2273,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2274,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2276,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2277,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2278,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2279,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2280,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2281,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2282,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2283,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2284,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2285,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2286,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2287,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2288,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2289,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2291,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2292,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2293,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2295,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2296,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2297,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2298,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2311,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2312,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2313,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2314,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2315,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2316,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2317,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2318,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2319,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2321,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2322,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2326,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2327,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2328,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2329,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2330,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2331,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2332,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2334,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2336,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2339,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2341,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2342,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2343,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2344,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2345,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2346,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2347,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2348,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2349,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2351,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2352,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2353,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2354,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2355,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2356,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2357,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2358,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2359,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2360,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2361,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2362,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2363,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2366,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2367,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2368,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2369,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2371,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2372,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2386,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2387,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2388,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2389,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2391,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2392,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2393,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2396,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2398,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2399,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2401,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2403,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2404,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2405,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2406,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2407,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2408,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2409,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2411,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2412,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2413,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2414,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2415,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2416,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2418,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2419,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2420,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2421,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2422,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2423,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2424,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2426,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2431,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2432,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2446,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2447,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2448,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2449,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2450,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2451,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2452,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2453,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2454,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2456,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2457,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2458,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2459,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2460,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2476,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2477,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2478,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2479,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2480,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2481,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2482,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2483,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2484,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2487,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2488,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2489,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2490,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2491,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2492,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2493,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2494,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2495,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2497,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2521,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2522,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2523,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2524,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2525,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2526,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2527,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2528,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2529,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2531,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2532,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2534,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2536,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2537,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2538,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2540,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2541,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2542,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2543,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2544,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2546,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2551,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2552,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2553,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2554,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2566,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2567,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2568,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2569,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2570,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2571,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2572,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2573,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2574,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2576,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2578,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2579,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2580,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2581,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2582,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2583,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2584,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2585,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2586,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2587,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2588,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2589,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2591,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2592,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2593,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2594,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2595,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2596,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2611,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2612,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2613,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2614,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2615,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2616,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2617,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2618,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2619,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2622,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2623,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2624,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2625,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2626,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2627,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2628,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2629,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2630,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2641,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2642,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2643,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2644,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2645,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2646,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2647,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2648,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2649,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2651,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2652,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2653,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2654,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2655,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2656,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2657,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2658,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2671,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2673,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2674,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2675,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2677,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2679,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2682,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2686,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2688,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2689,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2690,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2691,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2692,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2694,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2701,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2702,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2703,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2704,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2705,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2706,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2707,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2708,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2709,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2711,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2712,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2713,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2714,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2715,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2716,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2717,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2718,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2719,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2720,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2721,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2722,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2723,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2724,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2731,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2732,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2733,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2734,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2735,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2737,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2738,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2739,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2741,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2742,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2743,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2745,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2746,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2747,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2748,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2749,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2750,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2751,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2752,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2753,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2754,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2756,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2761,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2794,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2795,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2796,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2797,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2798,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2799,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2801,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2802,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2803,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2804,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2805,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2806,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2807,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2808,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2809,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2821,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2822,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2823,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2825,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2826,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2827,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2829,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2830,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2831,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2833,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2834,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2836,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2837,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2838,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2839,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2840,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2841,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2842,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2844,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2845,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2846,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2847,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2848,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2849,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2850,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2852,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2853,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2866,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2867,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2868,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2869,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2870,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2871,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2872,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2874,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2875,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2876,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2877,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2878,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2879,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2880,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2881,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2882,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2883,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2884,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2885,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2886,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2887,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2889,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2890,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2896,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2897,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2898,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2899,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2900,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2901,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2902,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2904,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2905,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2906,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2907,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2908,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2909,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2910,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2911,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2912,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2913,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2914,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2915,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2916,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2917,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2919,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2920,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2921,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2922,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2923,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2924,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2925,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2926,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2927,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2928,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2929,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2930,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2931,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2932,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2934,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2935,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2936,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2937,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2938,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2939,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2940,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2941,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2942,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2943,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2944,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2945,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2946,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2947,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2949,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2950,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2951,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2952,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2953,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2954,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2955,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2956,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2957,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2960,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2961,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2971,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2972,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2973,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2974,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2975,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2976,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2979,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2980,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2981,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2982,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2983,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2984,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2985,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2986,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2987,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2988,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2989,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2990,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2991,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2992,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2994,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2995,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2996,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2997,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2998,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 2999,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3000,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3001,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3002,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3003,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3004,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3005,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3006,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3009,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3010,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3011,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3013,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3014,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3016,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3017,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3019,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3020,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3021,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3022,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3024,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3025,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3028,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3031,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3032,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3033,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3034,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3035,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3036,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3037,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3039,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3040,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3041,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3042,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3044,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3045,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3046,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3048,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3049,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3050,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3061,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3062,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3063,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3064,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3065,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3066,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3067,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3069,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3070,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3071,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3072,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3073,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3074,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3075,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3076,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3077,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3078,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3079,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3080,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3081,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3082,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3084,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3091,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3092,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3093,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3094,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3095,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3106,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3107,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3108,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3110,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3112,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3114,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3115,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3116,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3117,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3118,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3119,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3120,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3121,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3122,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3123,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3124,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3125,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3126,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3127,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3129,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3130,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3131,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3132,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3133,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3134,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3135,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3136,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3137,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3138,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3139,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3142,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3151,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3152,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3153,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3155,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3156,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3157,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3159,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3160,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3161,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3166,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3167,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3168,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3170,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3171,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3174,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3175,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3176,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3177,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3178,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3179,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3180,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3181,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3182,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3183,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3184,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3185,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3187,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3189,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3190,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3191,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3194,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3195,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3196,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3197,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3198,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3199,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3200,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3201,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3202,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3211,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3213,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3226,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3227,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3228,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3229,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3230,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3231,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3232,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3234,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3235,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3236,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3237,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3238,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3239,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3240,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3241,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3242,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3243,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3244,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3246,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3256,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3257,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3258,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3259,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3260,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3261,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3262,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3265,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3266,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3268,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3269,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3271,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3272,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3273,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3274,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3275,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3276,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3277,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3280,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3281,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3286,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3287,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3288,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3289,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3290,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3291,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3294,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3295,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3296,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3298,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3299,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3300,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3301,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3302,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3303,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3304,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3305,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3306,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3307,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3309,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3310,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3311,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3312,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3314,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3315,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3332,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3346,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3347,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3348,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3349,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3351,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3352,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3354,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3355,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3356,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3357,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3358,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3359,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3361,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3362,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3363,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3364,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3365,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3366,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3376,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3377,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3378,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3379,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3380,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3381,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3382,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3385,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3386,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3387,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3388,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3389,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3390,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3391,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3392,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3393,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3394,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3395,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3406,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3421,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3422,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3423,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3424,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3425,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3426,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3427,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3429,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3430,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3431,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3432,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3433,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3434,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3435,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3437,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3438,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3439,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3440,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3441,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3451,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3452,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3453,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3454,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3456,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3457,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3459,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3460,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3461,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3462,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3463,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3464,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3465,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3466,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3467,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3468,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3469,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3470,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3471,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3472,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3474,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3475,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3476,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3477,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3479,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3480,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3481,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3482,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3483,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3484,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3485,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3486,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3487,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3489,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3490,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3491,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3492,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3493,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3494,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3495,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3496,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3497,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3498,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3499,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3500,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3501,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3502,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3505,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3511,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3512,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3513,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3514,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3515,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3516,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3517,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3519,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3520,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3521,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3522,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3523,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3524,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3525,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3527,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3529,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3530,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3531,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3532,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3534,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3536,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3537,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3541,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3542,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3543,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3544,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3545,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3546,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3547,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3549,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3550,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3551,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3552,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3553,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3556,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3557,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3558,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3559,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3560,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3561,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3562,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3564,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3565,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3566,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3567,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3568,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3569,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3570,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3571,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3572,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3573,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3574,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3575,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3576,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3586,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3587,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3588,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3589,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3590,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3591,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3592,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3594,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3595,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3596,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3597,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3598,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3599,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3600,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3601,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3602,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3603,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3604,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3605,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3606,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3609,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3610,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3611,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3612,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3613,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3614,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3616,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3618,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3620,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3621,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3622,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3624,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3625,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3631,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3632,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3633,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3634,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3635,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3636,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3646,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3647,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3648,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3649,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3650,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3651,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3652,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3654,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3655,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3656,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3657,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3658,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3659,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3660,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3661,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3662,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3663,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3664,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3665,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3666,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3667,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3670,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3676,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3677,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3678,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3679,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3680,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3681,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3682,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3684,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3685,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3686,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3687,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3688,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3689,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3690,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3691,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3692,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3693,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3694,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3695,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3696,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3697,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3699,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3700,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3701,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3702,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3703,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3704,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3705,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3706,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3707,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3708,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3709,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3710,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3712,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3714,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3715,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3721,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3722,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3723,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3724,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3737,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3738,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3739,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3740,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3741,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3751,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3753,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3754,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3755,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3756,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3757,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3758,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3759,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3760,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3761,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3762,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3763,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3764,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3765,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3766,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3768,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3770,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3771,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3773,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3775,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3776,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3777,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3783,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3784,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3785,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3786,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3787,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3788,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3789,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3790,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3793,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3796,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3798,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3799,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3800,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3801,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3802,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3803,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3804,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3806,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3807,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3808,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3809,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3811,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3813,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3814,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3815,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3816,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3817,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3818,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3819,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3820,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3821,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3822,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3823,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3826,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3828,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3829,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3836,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3839,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3843,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3845,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3846,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3847,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3848,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3850,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3852,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3856,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3858,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3859,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3860,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3863,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3864,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3865,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3866,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3867,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3868,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3869,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3870,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3871,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3874,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3875,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3876,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3877,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3878,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3880,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3881,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3882,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3883,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3885,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3886,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3888,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3891,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3894,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3895,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3896,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3898,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3901,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3903,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3904,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3905,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3907,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3908,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3909,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3912,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3916,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3918,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3919,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3921,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3922,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3923,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3924,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3925,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3926,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3927,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3928,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3929,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3930,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3931,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3934,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3935,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3948,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3949,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3951,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3952,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3953,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3954,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3955,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3956,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3957,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3958,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3959,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3960,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3961,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3964,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3965,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3966,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3968,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3969,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3970,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3971,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3972,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3973,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3976,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3978,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3980,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3982,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3983,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3984,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3985,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3986,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3987,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3988,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3990,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3991,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3993,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3994,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3996,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 3999,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4001,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4002,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4006,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4008,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4009,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4010,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4011,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4012,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4013,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4014,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4015,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4016,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4017,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4018,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4025,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4027,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4028,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4029,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4030,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4032,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4033,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4034,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4035,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4036,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4038,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4039,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4041,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4046,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4048,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4050,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4051,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4053,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4054,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4055,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4056,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4057,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4058,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4059,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4060,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4061,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4062,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4064,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4065,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4066,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4068,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4069,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4070,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4071,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4074,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4075,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4076,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4077,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4079,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4080,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4081,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4084,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4086,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4087,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4088,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4089,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4092,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4093,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4095,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4096,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4098,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4099,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4100,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4101,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4102,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4103,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4104,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4105,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4106,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4108,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4113,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4114,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4115,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4116,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4118,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4119,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4120,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4121,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4122,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4123,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4126,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4128,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4129,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4130,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4131,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4132,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4133,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4134,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4137,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4141,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4143,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4144,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4147,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4148,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4149,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4150,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4151,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4152,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4153,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4154,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4155,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4156,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4158,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4160,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4161,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4163,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4164,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4165,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4171,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4173,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4174,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4175,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4176,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4177,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4178,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4179,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4180,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4181,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4182,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4183,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4184,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4185,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4201,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4203,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4204,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4205,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4206,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4207,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4208,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4209,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4210,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4212,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4215,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4216,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4218,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4219,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4221,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4222,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4225,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4226,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4228,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4229,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4231,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4234,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4235,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4236,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4237,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4238,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4239,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4241,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4242,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4243,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4245,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4246,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4248,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4250,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4251,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4252,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4253,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4254,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4255,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4256,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4257,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4258,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

EnvioPractica::create([
'sesion_estudiante_id'  => 4260,
'en_laboratorio'        => 1,
'archivo'               => 'practica.zip',
]);

