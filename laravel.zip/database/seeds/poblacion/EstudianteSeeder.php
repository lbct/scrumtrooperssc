<?php use App\Models\Estudiante;
Estudiante::create([
'usuario_id' => 9,
'codigo_sis' => '201917409',
]);

Estudiante::create([
'usuario_id' => 10,
'codigo_sis' => '201948824',
]);

Estudiante::create([
'usuario_id' => 11,
'codigo_sis' => '201955171',
]);

Estudiante::create([
'usuario_id' => 12,
'codigo_sis' => '201915276',
]);

Estudiante::create([
'usuario_id' => 13,
'codigo_sis' => '201914232',
]);

Estudiante::create([
'usuario_id' => 14,
'codigo_sis' => '201921685',
]);

Estudiante::create([
'usuario_id' => 15,
'codigo_sis' => '201976189',
]);

Estudiante::create([
'usuario_id' => 16,
'codigo_sis' => '201927954',
]);

Estudiante::create([
'usuario_id' => 17,
'codigo_sis' => '201931233',
]);

Estudiante::create([
'usuario_id' => 18,
'codigo_sis' => '201941138',
]);

Estudiante::create([
'usuario_id' => 19,
'codigo_sis' => '201974277',
]);

Estudiante::create([
'usuario_id' => 20,
'codigo_sis' => '201993198',
]);

Estudiante::create([
'usuario_id' => 21,
'codigo_sis' => '201965028',
]);

Estudiante::create([
'usuario_id' => 22,
'codigo_sis' => '201960248',
]);

Estudiante::create([
'usuario_id' => 23,
'codigo_sis' => '201965090',
]);

Estudiante::create([
'usuario_id' => 24,
'codigo_sis' => '201906138',
]);

Estudiante::create([
'usuario_id' => 25,
'codigo_sis' => '201993446',
]);

Estudiante::create([
'usuario_id' => 26,
'codigo_sis' => '201906618',
]);

Estudiante::create([
'usuario_id' => 27,
'codigo_sis' => '201949637',
]);

Estudiante::create([
'usuario_id' => 28,
'codigo_sis' => '201988291',
]);

Estudiante::create([
'usuario_id' => 29,
'codigo_sis' => '201935984',
]);

Estudiante::create([
'usuario_id' => 30,
'codigo_sis' => '201907636',
]);

Estudiante::create([
'usuario_id' => 31,
'codigo_sis' => '201915420',
]);

Estudiante::create([
'usuario_id' => 32,
'codigo_sis' => '201997372',
]);

Estudiante::create([
'usuario_id' => 33,
'codigo_sis' => '201960165',
]);

Estudiante::create([
'usuario_id' => 34,
'codigo_sis' => '201975412',
]);

Estudiante::create([
'usuario_id' => 35,
'codigo_sis' => '201900146',
]);

Estudiante::create([
'usuario_id' => 36,
'codigo_sis' => '201907177',
]);

Estudiante::create([
'usuario_id' => 37,
'codigo_sis' => '201977335',
]);

Estudiante::create([
'usuario_id' => 38,
'codigo_sis' => '201999818',
]);

Estudiante::create([
'usuario_id' => 39,
'codigo_sis' => '201926603',
]);

Estudiante::create([
'usuario_id' => 40,
'codigo_sis' => '201980125',
]);

Estudiante::create([
'usuario_id' => 41,
'codigo_sis' => '201909478',
]);

Estudiante::create([
'usuario_id' => 42,
'codigo_sis' => '201935120',
]);

Estudiante::create([
'usuario_id' => 43,
'codigo_sis' => '201916406',
]);

Estudiante::create([
'usuario_id' => 44,
'codigo_sis' => '201918984',
]);

Estudiante::create([
'usuario_id' => 45,
'codigo_sis' => '201914398',
]);

Estudiante::create([
'usuario_id' => 46,
'codigo_sis' => '201980877',
]);

Estudiante::create([
'usuario_id' => 47,
'codigo_sis' => '201983837',
]);

Estudiante::create([
'usuario_id' => 48,
'codigo_sis' => '201910734',
]);

Estudiante::create([
'usuario_id' => 49,
'codigo_sis' => '201996510',
]);

Estudiante::create([
'usuario_id' => 50,
'codigo_sis' => '201999683',
]);

Estudiante::create([
'usuario_id' => 51,
'codigo_sis' => '201948499',
]);

Estudiante::create([
'usuario_id' => 52,
'codigo_sis' => '201925533',
]);

Estudiante::create([
'usuario_id' => 53,
'codigo_sis' => '201937438',
]);

Estudiante::create([
'usuario_id' => 54,
'codigo_sis' => '201908806',
]);

Estudiante::create([
'usuario_id' => 55,
'codigo_sis' => '201981989',
]);

Estudiante::create([
'usuario_id' => 56,
'codigo_sis' => '201972282',
]);

Estudiante::create([
'usuario_id' => 57,
'codigo_sis' => '201989078',
]);

Estudiante::create([
'usuario_id' => 58,
'codigo_sis' => '201915861',
]);

Estudiante::create([
'usuario_id' => 59,
'codigo_sis' => '201924258',
]);

Estudiante::create([
'usuario_id' => 60,
'codigo_sis' => '201962653',
]);

Estudiante::create([
'usuario_id' => 61,
'codigo_sis' => '201992461',
]);

Estudiante::create([
'usuario_id' => 62,
'codigo_sis' => '201982119',
]);

Estudiante::create([
'usuario_id' => 63,
'codigo_sis' => '201976295',
]);

Estudiante::create([
'usuario_id' => 64,
'codigo_sis' => '201920039',
]);

Estudiante::create([
'usuario_id' => 65,
'codigo_sis' => '201918195',
]);

Estudiante::create([
'usuario_id' => 66,
'codigo_sis' => '201932525',
]);

Estudiante::create([
'usuario_id' => 67,
'codigo_sis' => '201986772',
]);

Estudiante::create([
'usuario_id' => 68,
'codigo_sis' => '201929419',
]);

Estudiante::create([
'usuario_id' => 69,
'codigo_sis' => '201969825',
]);

Estudiante::create([
'usuario_id' => 70,
'codigo_sis' => '201954912',
]);

Estudiante::create([
'usuario_id' => 71,
'codigo_sis' => '201950839',
]);

Estudiante::create([
'usuario_id' => 72,
'codigo_sis' => '201939679',
]);

Estudiante::create([
'usuario_id' => 73,
'codigo_sis' => '201997693',
]);

Estudiante::create([
'usuario_id' => 74,
'codigo_sis' => '201957665',
]);

Estudiante::create([
'usuario_id' => 75,
'codigo_sis' => '201982544',
]);

Estudiante::create([
'usuario_id' => 76,
'codigo_sis' => '201916163',
]);

Estudiante::create([
'usuario_id' => 77,
'codigo_sis' => '201935532',
]);

Estudiante::create([
'usuario_id' => 78,
'codigo_sis' => '201982536',
]);

Estudiante::create([
'usuario_id' => 79,
'codigo_sis' => '201918621',
]);

Estudiante::create([
'usuario_id' => 80,
'codigo_sis' => '201946291',
]);

Estudiante::create([
'usuario_id' => 81,
'codigo_sis' => '201950364',
]);

Estudiante::create([
'usuario_id' => 82,
'codigo_sis' => '201992934',
]);

Estudiante::create([
'usuario_id' => 83,
'codigo_sis' => '201940596',
]);

Estudiante::create([
'usuario_id' => 84,
'codigo_sis' => '201934288',
]);

Estudiante::create([
'usuario_id' => 85,
'codigo_sis' => '201975812',
]);

Estudiante::create([
'usuario_id' => 86,
'codigo_sis' => '201957444',
]);

Estudiante::create([
'usuario_id' => 87,
'codigo_sis' => '201944293',
]);

Estudiante::create([
'usuario_id' => 88,
'codigo_sis' => '201907787',
]);

Estudiante::create([
'usuario_id' => 89,
'codigo_sis' => '201930382',
]);

Estudiante::create([
'usuario_id' => 90,
'codigo_sis' => '201952037',
]);

Estudiante::create([
'usuario_id' => 91,
'codigo_sis' => '201929753',
]);

Estudiante::create([
'usuario_id' => 92,
'codigo_sis' => '201943211',
]);

Estudiante::create([
'usuario_id' => 93,
'codigo_sis' => '201932535',
]);

Estudiante::create([
'usuario_id' => 94,
'codigo_sis' => '201912226',
]);

Estudiante::create([
'usuario_id' => 95,
'codigo_sis' => '201940703',
]);

Estudiante::create([
'usuario_id' => 96,
'codigo_sis' => '201940053',
]);

Estudiante::create([
'usuario_id' => 97,
'codigo_sis' => '201910675',
]);

Estudiante::create([
'usuario_id' => 98,
'codigo_sis' => '201900454',
]);

Estudiante::create([
'usuario_id' => 99,
'codigo_sis' => '201995648',
]);

Estudiante::create([
'usuario_id' => 100,
'codigo_sis' => '201921683',
]);

Estudiante::create([
'usuario_id' => 101,
'codigo_sis' => '201914849',
]);

Estudiante::create([
'usuario_id' => 102,
'codigo_sis' => '201920706',
]);

Estudiante::create([
'usuario_id' => 103,
'codigo_sis' => '201907056',
]);

Estudiante::create([
'usuario_id' => 104,
'codigo_sis' => '201973849',
]);

Estudiante::create([
'usuario_id' => 105,
'codigo_sis' => '201926577',
]);

Estudiante::create([
'usuario_id' => 106,
'codigo_sis' => '201945798',
]);

Estudiante::create([
'usuario_id' => 107,
'codigo_sis' => '201930223',
]);

Estudiante::create([
'usuario_id' => 108,
'codigo_sis' => '201967155',
]);

Estudiante::create([
'usuario_id' => 109,
'codigo_sis' => '201940260',
]);

Estudiante::create([
'usuario_id' => 110,
'codigo_sis' => '201961117',
]);

Estudiante::create([
'usuario_id' => 111,
'codigo_sis' => '201930048',
]);

Estudiante::create([
'usuario_id' => 112,
'codigo_sis' => '201930129',
]);

Estudiante::create([
'usuario_id' => 113,
'codigo_sis' => '201903885',
]);

Estudiante::create([
'usuario_id' => 114,
'codigo_sis' => '201977089',
]);

Estudiante::create([
'usuario_id' => 115,
'codigo_sis' => '201930747',
]);

Estudiante::create([
'usuario_id' => 116,
'codigo_sis' => '201983710',
]);

Estudiante::create([
'usuario_id' => 117,
'codigo_sis' => '201908345',
]);

Estudiante::create([
'usuario_id' => 118,
'codigo_sis' => '201901456',
]);

Estudiante::create([
'usuario_id' => 119,
'codigo_sis' => '201920356',
]);

Estudiante::create([
'usuario_id' => 120,
'codigo_sis' => '201966767',
]);

Estudiante::create([
'usuario_id' => 121,
'codigo_sis' => '201971916',
]);

Estudiante::create([
'usuario_id' => 122,
'codigo_sis' => '201927276',
]);

Estudiante::create([
'usuario_id' => 123,
'codigo_sis' => '201951399',
]);

Estudiante::create([
'usuario_id' => 124,
'codigo_sis' => '201959265',
]);

Estudiante::create([
'usuario_id' => 125,
'codigo_sis' => '201932444',
]);

Estudiante::create([
'usuario_id' => 126,
'codigo_sis' => '201927923',
]);

Estudiante::create([
'usuario_id' => 127,
'codigo_sis' => '201973157',
]);

Estudiante::create([
'usuario_id' => 128,
'codigo_sis' => '201985832',
]);

Estudiante::create([
'usuario_id' => 129,
'codigo_sis' => '201941159',
]);

Estudiante::create([
'usuario_id' => 130,
'codigo_sis' => '201951064',
]);

Estudiante::create([
'usuario_id' => 131,
'codigo_sis' => '201953089',
]);

Estudiante::create([
'usuario_id' => 132,
'codigo_sis' => '201913474',
]);

Estudiante::create([
'usuario_id' => 133,
'codigo_sis' => '201963652',
]);

Estudiante::create([
'usuario_id' => 134,
'codigo_sis' => '201981031',
]);

Estudiante::create([
'usuario_id' => 135,
'codigo_sis' => '201955221',
]);

Estudiante::create([
'usuario_id' => 136,
'codigo_sis' => '201974823',
]);

Estudiante::create([
'usuario_id' => 137,
'codigo_sis' => '201963035',
]);

Estudiante::create([
'usuario_id' => 138,
'codigo_sis' => '201928072',
]);

Estudiante::create([
'usuario_id' => 139,
'codigo_sis' => '201925910',
]);

Estudiante::create([
'usuario_id' => 140,
'codigo_sis' => '201985079',
]);

Estudiante::create([
'usuario_id' => 141,
'codigo_sis' => '201905341',
]);

Estudiante::create([
'usuario_id' => 142,
'codigo_sis' => '201904859',
]);

Estudiante::create([
'usuario_id' => 143,
'codigo_sis' => '201925413',
]);

Estudiante::create([
'usuario_id' => 144,
'codigo_sis' => '201995827',
]);

Estudiante::create([
'usuario_id' => 145,
'codigo_sis' => '201996177',
]);

Estudiante::create([
'usuario_id' => 146,
'codigo_sis' => '201919034',
]);

Estudiante::create([
'usuario_id' => 147,
'codigo_sis' => '201917533',
]);

Estudiante::create([
'usuario_id' => 148,
'codigo_sis' => '201924129',
]);

Estudiante::create([
'usuario_id' => 149,
'codigo_sis' => '201908745',
]);

Estudiante::create([
'usuario_id' => 150,
'codigo_sis' => '201968077',
]);

Estudiante::create([
'usuario_id' => 151,
'codigo_sis' => '201943136',
]);

Estudiante::create([
'usuario_id' => 152,
'codigo_sis' => '201930190',
]);

Estudiante::create([
'usuario_id' => 153,
'codigo_sis' => '201942931',
]);

Estudiante::create([
'usuario_id' => 154,
'codigo_sis' => '201948205',
]);

Estudiante::create([
'usuario_id' => 155,
'codigo_sis' => '201959328',
]);

Estudiante::create([
'usuario_id' => 156,
'codigo_sis' => '201974814',
]);

Estudiante::create([
'usuario_id' => 157,
'codigo_sis' => '201935526',
]);

Estudiante::create([
'usuario_id' => 158,
'codigo_sis' => '201989295',
]);

Estudiante::create([
'usuario_id' => 159,
'codigo_sis' => '201994505',
]);

Estudiante::create([
'usuario_id' => 160,
'codigo_sis' => '201988013',
]);

Estudiante::create([
'usuario_id' => 161,
'codigo_sis' => '201922270',
]);

Estudiante::create([
'usuario_id' => 162,
'codigo_sis' => '201931337',
]);

Estudiante::create([
'usuario_id' => 163,
'codigo_sis' => '201909558',
]);

Estudiante::create([
'usuario_id' => 164,
'codigo_sis' => '201937837',
]);

Estudiante::create([
'usuario_id' => 165,
'codigo_sis' => '201993918',
]);

Estudiante::create([
'usuario_id' => 166,
'codigo_sis' => '201928018',
]);

Estudiante::create([
'usuario_id' => 167,
'codigo_sis' => '201948609',
]);

Estudiante::create([
'usuario_id' => 168,
'codigo_sis' => '201930087',
]);

Estudiante::create([
'usuario_id' => 169,
'codigo_sis' => '201963565',
]);

Estudiante::create([
'usuario_id' => 170,
'codigo_sis' => '201983948',
]);

Estudiante::create([
'usuario_id' => 171,
'codigo_sis' => '201939764',
]);

Estudiante::create([
'usuario_id' => 172,
'codigo_sis' => '201958615',
]);

Estudiante::create([
'usuario_id' => 173,
'codigo_sis' => '201951964',
]);

Estudiante::create([
'usuario_id' => 174,
'codigo_sis' => '201954253',
]);

Estudiante::create([
'usuario_id' => 175,
'codigo_sis' => '201926826',
]);

Estudiante::create([
'usuario_id' => 176,
'codigo_sis' => '201963945',
]);

Estudiante::create([
'usuario_id' => 177,
'codigo_sis' => '201962535',
]);

Estudiante::create([
'usuario_id' => 178,
'codigo_sis' => '201966144',
]);

Estudiante::create([
'usuario_id' => 179,
'codigo_sis' => '201962682',
]);

Estudiante::create([
'usuario_id' => 180,
'codigo_sis' => '201955101',
]);

Estudiante::create([
'usuario_id' => 181,
'codigo_sis' => '201951760',
]);

Estudiante::create([
'usuario_id' => 182,
'codigo_sis' => '201902433',
]);

Estudiante::create([
'usuario_id' => 183,
'codigo_sis' => '201962823',
]);

Estudiante::create([
'usuario_id' => 184,
'codigo_sis' => '201943436',
]);

Estudiante::create([
'usuario_id' => 185,
'codigo_sis' => '201984739',
]);

Estudiante::create([
'usuario_id' => 186,
'codigo_sis' => '201980088',
]);

Estudiante::create([
'usuario_id' => 187,
'codigo_sis' => '201905143',
]);

Estudiante::create([
'usuario_id' => 188,
'codigo_sis' => '201963921',
]);

Estudiante::create([
'usuario_id' => 189,
'codigo_sis' => '201998234',
]);

Estudiante::create([
'usuario_id' => 190,
'codigo_sis' => '201902319',
]);

Estudiante::create([
'usuario_id' => 191,
'codigo_sis' => '201989891',
]);

Estudiante::create([
'usuario_id' => 192,
'codigo_sis' => '201935142',
]);

Estudiante::create([
'usuario_id' => 193,
'codigo_sis' => '201953892',
]);

Estudiante::create([
'usuario_id' => 194,
'codigo_sis' => '201987014',
]);

Estudiante::create([
'usuario_id' => 195,
'codigo_sis' => '201981935',
]);

Estudiante::create([
'usuario_id' => 196,
'codigo_sis' => '201997980',
]);

Estudiante::create([
'usuario_id' => 197,
'codigo_sis' => '201914755',
]);

Estudiante::create([
'usuario_id' => 198,
'codigo_sis' => '201950928',
]);

Estudiante::create([
'usuario_id' => 199,
'codigo_sis' => '201924504',
]);

Estudiante::create([
'usuario_id' => 200,
'codigo_sis' => '201940511',
]);

Estudiante::create([
'usuario_id' => 201,
'codigo_sis' => '201959083',
]);

Estudiante::create([
'usuario_id' => 202,
'codigo_sis' => '201987269',
]);

Estudiante::create([
'usuario_id' => 203,
'codigo_sis' => '201938103',
]);

Estudiante::create([
'usuario_id' => 204,
'codigo_sis' => '201938480',
]);

Estudiante::create([
'usuario_id' => 205,
'codigo_sis' => '201915413',
]);

Estudiante::create([
'usuario_id' => 206,
'codigo_sis' => '201973585',
]);

Estudiante::create([
'usuario_id' => 207,
'codigo_sis' => '201969089',
]);

Estudiante::create([
'usuario_id' => 208,
'codigo_sis' => '201936069',
]);

Estudiante::create([
'usuario_id' => 209,
'codigo_sis' => '201978941',
]);

Estudiante::create([
'usuario_id' => 210,
'codigo_sis' => '201956666',
]);

Estudiante::create([
'usuario_id' => 211,
'codigo_sis' => '201967140',
]);

Estudiante::create([
'usuario_id' => 212,
'codigo_sis' => '201961214',
]);

Estudiante::create([
'usuario_id' => 213,
'codigo_sis' => '201995234',
]);

Estudiante::create([
'usuario_id' => 214,
'codigo_sis' => '201915231',
]);

Estudiante::create([
'usuario_id' => 215,
'codigo_sis' => '201968827',
]);

Estudiante::create([
'usuario_id' => 216,
'codigo_sis' => '201971260',
]);

Estudiante::create([
'usuario_id' => 217,
'codigo_sis' => '201949460',
]);

Estudiante::create([
'usuario_id' => 218,
'codigo_sis' => '201936245',
]);

Estudiante::create([
'usuario_id' => 219,
'codigo_sis' => '201988121',
]);

Estudiante::create([
'usuario_id' => 220,
'codigo_sis' => '201949824',
]);

Estudiante::create([
'usuario_id' => 221,
'codigo_sis' => '201952998',
]);

Estudiante::create([
'usuario_id' => 222,
'codigo_sis' => '201938698',
]);

Estudiante::create([
'usuario_id' => 223,
'codigo_sis' => '201966238',
]);

Estudiante::create([
'usuario_id' => 224,
'codigo_sis' => '201926275',
]);

Estudiante::create([
'usuario_id' => 225,
'codigo_sis' => '201978278',
]);

Estudiante::create([
'usuario_id' => 226,
'codigo_sis' => '201902089',
]);

Estudiante::create([
'usuario_id' => 227,
'codigo_sis' => '201928205',
]);

Estudiante::create([
'usuario_id' => 228,
'codigo_sis' => '201952767',
]);

Estudiante::create([
'usuario_id' => 229,
'codigo_sis' => '201987816',
]);

Estudiante::create([
'usuario_id' => 230,
'codigo_sis' => '201909589',
]);

Estudiante::create([
'usuario_id' => 231,
'codigo_sis' => '201900072',
]);

Estudiante::create([
'usuario_id' => 232,
'codigo_sis' => '201955214',
]);

Estudiante::create([
'usuario_id' => 233,
'codigo_sis' => '201986468',
]);

Estudiante::create([
'usuario_id' => 234,
'codigo_sis' => '201998355',
]);

Estudiante::create([
'usuario_id' => 235,
'codigo_sis' => '201915584',
]);

Estudiante::create([
'usuario_id' => 236,
'codigo_sis' => '201905472',
]);

Estudiante::create([
'usuario_id' => 237,
'codigo_sis' => '201914990',
]);

Estudiante::create([
'usuario_id' => 238,
'codigo_sis' => '201930350',
]);

Estudiante::create([
'usuario_id' => 239,
'codigo_sis' => '201976783',
]);

Estudiante::create([
'usuario_id' => 240,
'codigo_sis' => '201964419',
]);

Estudiante::create([
'usuario_id' => 241,
'codigo_sis' => '201955747',
]);

Estudiante::create([
'usuario_id' => 242,
'codigo_sis' => '201934088',
]);

Estudiante::create([
'usuario_id' => 243,
'codigo_sis' => '201915232',
]);

Estudiante::create([
'usuario_id' => 244,
'codigo_sis' => '201946662',
]);

Estudiante::create([
'usuario_id' => 245,
'codigo_sis' => '201990493',
]);

Estudiante::create([
'usuario_id' => 246,
'codigo_sis' => '201911995',
]);

Estudiante::create([
'usuario_id' => 247,
'codigo_sis' => '201955605',
]);

Estudiante::create([
'usuario_id' => 248,
'codigo_sis' => '201994634',
]);

Estudiante::create([
'usuario_id' => 249,
'codigo_sis' => '201990539',
]);

Estudiante::create([
'usuario_id' => 250,
'codigo_sis' => '201912881',
]);

Estudiante::create([
'usuario_id' => 251,
'codigo_sis' => '201986024',
]);

Estudiante::create([
'usuario_id' => 252,
'codigo_sis' => '201990221',
]);

Estudiante::create([
'usuario_id' => 253,
'codigo_sis' => '201954442',
]);

Estudiante::create([
'usuario_id' => 254,
'codigo_sis' => '201950421',
]);

Estudiante::create([
'usuario_id' => 255,
'codigo_sis' => '201927795',
]);

Estudiante::create([
'usuario_id' => 256,
'codigo_sis' => '201954034',
]);

Estudiante::create([
'usuario_id' => 257,
'codigo_sis' => '201912298',
]);

Estudiante::create([
'usuario_id' => 258,
'codigo_sis' => '201922785',
]);

Estudiante::create([
'usuario_id' => 259,
'codigo_sis' => '201983944',
]);

Estudiante::create([
'usuario_id' => 260,
'codigo_sis' => '201969856',
]);

Estudiante::create([
'usuario_id' => 261,
'codigo_sis' => '201960727',
]);

Estudiante::create([
'usuario_id' => 262,
'codigo_sis' => '201926471',
]);

Estudiante::create([
'usuario_id' => 263,
'codigo_sis' => '201932163',
]);

Estudiante::create([
'usuario_id' => 264,
'codigo_sis' => '201983286',
]);

Estudiante::create([
'usuario_id' => 265,
'codigo_sis' => '201901260',
]);

Estudiante::create([
'usuario_id' => 266,
'codigo_sis' => '201954679',
]);

Estudiante::create([
'usuario_id' => 267,
'codigo_sis' => '201934788',
]);

Estudiante::create([
'usuario_id' => 268,
'codigo_sis' => '201916387',
]);

Estudiante::create([
'usuario_id' => 269,
'codigo_sis' => '201961723',
]);

Estudiante::create([
'usuario_id' => 270,
'codigo_sis' => '201978585',
]);

Estudiante::create([
'usuario_id' => 271,
'codigo_sis' => '201987331',
]);

Estudiante::create([
'usuario_id' => 272,
'codigo_sis' => '201908109',
]);

Estudiante::create([
'usuario_id' => 273,
'codigo_sis' => '201924915',
]);

Estudiante::create([
'usuario_id' => 274,
'codigo_sis' => '201973342',
]);

Estudiante::create([
'usuario_id' => 275,
'codigo_sis' => '201920127',
]);

Estudiante::create([
'usuario_id' => 276,
'codigo_sis' => '201970241',
]);

Estudiante::create([
'usuario_id' => 277,
'codigo_sis' => '201903739',
]);

Estudiante::create([
'usuario_id' => 278,
'codigo_sis' => '201959720',
]);

Estudiante::create([
'usuario_id' => 279,
'codigo_sis' => '201928670',
]);

Estudiante::create([
'usuario_id' => 280,
'codigo_sis' => '201981830',
]);

Estudiante::create([
'usuario_id' => 281,
'codigo_sis' => '201936202',
]);

Estudiante::create([
'usuario_id' => 282,
'codigo_sis' => '201984183',
]);

Estudiante::create([
'usuario_id' => 283,
'codigo_sis' => '201975817',
]);

Estudiante::create([
'usuario_id' => 284,
'codigo_sis' => '201904881',
]);

Estudiante::create([
'usuario_id' => 285,
'codigo_sis' => '201936789',
]);

Estudiante::create([
'usuario_id' => 286,
'codigo_sis' => '201955566',
]);

Estudiante::create([
'usuario_id' => 287,
'codigo_sis' => '201930088',
]);

Estudiante::create([
'usuario_id' => 288,
'codigo_sis' => '201923065',
]);

Estudiante::create([
'usuario_id' => 289,
'codigo_sis' => '201909722',
]);

Estudiante::create([
'usuario_id' => 290,
'codigo_sis' => '201982944',
]);

Estudiante::create([
'usuario_id' => 291,
'codigo_sis' => '201982725',
]);

Estudiante::create([
'usuario_id' => 292,
'codigo_sis' => '201984739',
]);

