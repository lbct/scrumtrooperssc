<?php use App\Models\Sesion;
Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 1,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 2,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 3,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 4,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 5,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 6,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 7,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 8,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 1,
'semana'               => 1,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 2,
'semana'               => 2,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 3,
'semana'               => 3,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 4,
'semana'               => 4,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 5,
'semana'               => 5,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 6,
'semana'               => 6,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 7,
'semana'               => 7,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 8,
'semana'               => 8,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 9,
'semana'               => 9,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 10,
'semana'               => 10,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 11,
'semana'               => 11,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 12,
'semana'               => 12,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 13,
'semana'               => 13,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 14,
'semana'               => 14,
]);

Sesion::create([
'clase_id'             => 9,
'auxiliar_terminal_id' => 1,
'guia_practica_id'     => 15,
'semana'               => 15,
]);

