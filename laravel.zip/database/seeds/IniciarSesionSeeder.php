<?php

use Illuminate\Database\Seeder;
use App\Models\IniciarSesion;

class IniciarSesionSeeder extends Seeder
{
    public function run()
    {
    }
}
