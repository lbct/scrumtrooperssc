<?php

use Illuminate\Database\Seeder;
use App\Models\SesionEstudiante;

class SesionEstudianteSeeder extends Seeder
{
    public function run()
    {
    }
}
