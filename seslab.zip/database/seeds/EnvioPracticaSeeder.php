<?php

use Illuminate\Database\Seeder;
use App\Models\EnvioPractica;

class EnvioPracticaSeeder extends Seeder
{
    public function run()
    {
    }
}
