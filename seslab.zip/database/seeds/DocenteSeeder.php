<?php

use Illuminate\Database\Seeder;
use App\Models\Docente;

class DocenteSeeder extends Seeder
{
    public function run()
    {
        Docente::create([
        	'usuario_id' 		=>	2,
        ]);
        
        Docente::create([
        	'usuario_id' 		=>	3,
        ]);
        
        Docente::create([
        	'usuario_id' 		=>	4,
        ]);
    }
}
