<?php

use Illuminate\Database\Seeder;
use App\Models\Auxiliar;

class AuxiliarSeeder extends Seeder
{
    public function run()
    {
        //ID = 1
        Auxiliar::create([
        	'usuario_id' 		=>	5,
        ]);
        
        //ID = 2
        Auxiliar::create([
        	'usuario_id' 		=>	6,
        ]);
        
        //ID = 3
        Auxiliar::create([
        	'usuario_id' 		=>	7,
        ]);
        
        //ID = 4
        Auxiliar::create([
        	'usuario_id' 		=>	8,
        ]);
    }
}
