<ul class="nav">
    @include('sidebar.administrador')
    @include('sidebar.docente')
    @include('sidebar.auxiliar_terminal')
    @include('sidebar.auxiliar_laboratorio')
    @include('sidebar.estudiante')
</ul>