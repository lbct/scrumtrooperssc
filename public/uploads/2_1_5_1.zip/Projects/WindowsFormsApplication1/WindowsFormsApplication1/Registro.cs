﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class Registro
    {
        private int[] ingresos;
        private int[] salidas;
        private string[] fecha;
        private int actual;

        public Registro()
        {
            actual = 0;
            ingresos = new int[1000];
            salidas = new int[1000];
            fecha = new string[1000];
        }

        public void establecerIngreso()
        {
            this.fecha[actual] = DateTime.Now.ToString();
            this.ingresos[actual] = DateTime.Now.Hour * 60 + DateTime.Now.Minute;
        }

        public int getHorasTrabajo()
        {
            int actualMin = DateTime.Now.Hour * 60 + DateTime.Now.Minute;
            salidas[actual] = actualMin;
            int res = salidas[actual] - ingresos[actual];
            actual++;
            return res / 60;
        }

        public string toString()
        {
            string reg = "";
            for (int i = 0; i < actual; i++)
            {
                reg += "En fecha: " + fecha[i] + " Trabajo " + ((salidas[i] - ingresos[i]) / 60) + " Horas\n";
            }
            return reg;
        }
        public int darHorasTotales()
        {
            int sum = 0;
            for (int i = 0; i < actual; i++)
            {
                sum+= ((salidas[i] - ingresos[i]) / 60);
            }
            return sum;
        }
        public void borrar()
        {
            actual = 0;
        }
    }
}
