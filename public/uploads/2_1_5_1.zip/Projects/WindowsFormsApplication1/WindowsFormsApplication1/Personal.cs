﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class Personal
    {
        private string nombre;
        private string carnet;
        private string telefono;
        private Registro registro;
        private int categoria;
        private bool ingreso;

        public Personal(string nombre, string carnet, string telefono, int categoria)
        {
            this.carnet = carnet;
            this.telefono = telefono;
            this.nombre = nombre;
            this.categoria = categoria;
            registro = new Registro();
            ingreso = false;
        }

        public void ingresar()
        {
            registro.establecerIngreso();
            ingreso = true;
        }

        public int darSalario()
        {
            int porHora;
            if (categoria == 0)
            {
                porHora = 100;
            }
            else if (categoria == 1)
            {
                porHora = 200;
            }
            else
            {
                porHora = 300;
            }
            return registro.getHorasTrabajo() * porHora;
            ingreso = false;
        }

        public bool Ingreso()
        {
            return ingreso;
        }

        public string getNombre()
        {
            return nombre;
        }

        public string getCarnet()
        {
            return carnet;
        }

        public string getTelefono()
        {
            return telefono;
        }

        public string getRegistro()
        {
            string reg = "REGISTRO DE " + nombre + " CON CI " + carnet + " Y TELEF: " + telefono + "\n\n";
            reg += registro.toString();
            return reg;
        }
        public int getCategoria()
        {
            return categoria;
        }

        public string toString()
        {
            return nombre + " " + carnet;
        }
        public int darTotal()
        {
            int porHora;
            if (categoria == 0)
            {
                porHora = 100;
            }
            else if (categoria == 1)
            {
                porHora = 200;
            }
            else
            {
                porHora = 300;
            }
            return registro.darHorasTotales() * porHora;
        }

        public void cancelar()
        {
            registro.borrar();
        }
    }
}
