﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nombre = new System.Windows.Forms.TextBox();
            this.carnet = new System.Windows.Forms.TextBox();
            this.telefono = new System.Windows.Forms.TextBox();
            this.botonRegistrar = new System.Windows.Forms.Button();
            this.categoriaA = new System.Windows.Forms.RadioButton();
            this.categoriaC = new System.Windows.Forms.RadioButton();
            this.categoriaB = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Personal = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.categoriaA2 = new System.Windows.Forms.RadioButton();
            this.categoriaB2 = new System.Windows.Forms.RadioButton();
            this.categoriaC2 = new System.Windows.Forms.RadioButton();
            this.lista = new System.Windows.Forms.ComboBox();
            this.botonSalida = new System.Windows.Forms.Button();
            this.botonIngreso = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.total = new System.Windows.Forms.Label();
            this.botonCancelar = new System.Windows.Forms.Button();
            this.registro = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.Personal.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Carnet";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Telefono";
            // 
            // nombre
            // 
            this.nombre.Location = new System.Drawing.Point(58, 5);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(100, 20);
            this.nombre.TabIndex = 3;
            // 
            // carnet
            // 
            this.carnet.Location = new System.Drawing.Point(58, 35);
            this.carnet.Name = "carnet";
            this.carnet.Size = new System.Drawing.Size(100, 20);
            this.carnet.TabIndex = 4;
            // 
            // telefono
            // 
            this.telefono.Location = new System.Drawing.Point(58, 67);
            this.telefono.Name = "telefono";
            this.telefono.Size = new System.Drawing.Size(100, 20);
            this.telefono.TabIndex = 5;
            // 
            // botonRegistrar
            // 
            this.botonRegistrar.Location = new System.Drawing.Point(449, 222);
            this.botonRegistrar.Name = "botonRegistrar";
            this.botonRegistrar.Size = new System.Drawing.Size(75, 23);
            this.botonRegistrar.TabIndex = 6;
            this.botonRegistrar.Text = "Registrar";
            this.botonRegistrar.UseVisualStyleBackColor = true;
            this.botonRegistrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // categoriaA
            // 
            this.categoriaA.AutoSize = true;
            this.categoriaA.Checked = true;
            this.categoriaA.Location = new System.Drawing.Point(6, 19);
            this.categoriaA.Name = "categoriaA";
            this.categoriaA.Size = new System.Drawing.Size(72, 17);
            this.categoriaA.TabIndex = 7;
            this.categoriaA.TabStop = true;
            this.categoriaA.Text = "Empleado";
            this.categoriaA.UseVisualStyleBackColor = true;
            // 
            // categoriaC
            // 
            this.categoriaC.AutoSize = true;
            this.categoriaC.Location = new System.Drawing.Point(6, 65);
            this.categoriaC.Name = "categoriaC";
            this.categoriaC.Size = new System.Drawing.Size(63, 17);
            this.categoriaC.TabIndex = 8;
            this.categoriaC.Text = "Gerente";
            this.categoriaC.UseVisualStyleBackColor = true;
            // 
            // categoriaB
            // 
            this.categoriaB.AutoSize = true;
            this.categoriaB.Location = new System.Drawing.Point(6, 42);
            this.categoriaB.Name = "categoriaB";
            this.categoriaB.Size = new System.Drawing.Size(75, 17);
            this.categoriaB.TabIndex = 9;
            this.categoriaB.Text = "Supervisor";
            this.categoriaB.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.categoriaA);
            this.groupBox1.Controls.Add(this.categoriaB);
            this.groupBox1.Controls.Add(this.categoriaC);
            this.groupBox1.Location = new System.Drawing.Point(6, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Categorias";
            // 
            // Personal
            // 
            this.Personal.Controls.Add(this.tabPage1);
            this.Personal.Controls.Add(this.tabPage2);
            this.Personal.Location = new System.Drawing.Point(2, 3);
            this.Personal.Name = "Personal";
            this.Personal.SelectedIndex = 0;
            this.Personal.Size = new System.Drawing.Size(541, 299);
            this.Personal.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.botonRegistrar);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.telefono);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.carnet);
            this.tabPage1.Controls.Add(this.nombre);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(533, 273);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Personal";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.registro);
            this.tabPage2.Controls.Add(this.botonCancelar);
            this.tabPage2.Controls.Add(this.total);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.botonIngreso);
            this.tabPage2.Controls.Add(this.botonSalida);
            this.tabPage2.Controls.Add(this.lista);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(533, 273);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.categoriaC2);
            this.groupBox2.Controls.Add(this.categoriaB2);
            this.groupBox2.Controls.Add(this.categoriaA2);
            this.groupBox2.Location = new System.Drawing.Point(7, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Categoria";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // categoriaA2
            // 
            this.categoriaA2.AutoSize = true;
            this.categoriaA2.Location = new System.Drawing.Point(7, 20);
            this.categoriaA2.Name = "categoriaA2";
            this.categoriaA2.Size = new System.Drawing.Size(72, 17);
            this.categoriaA2.TabIndex = 0;
            this.categoriaA2.Text = "Empleado";
            this.categoriaA2.UseVisualStyleBackColor = true;
            this.categoriaA2.CheckedChanged += new System.EventHandler(this.categoriaA2_CheckedChanged);
            // 
            // categoriaB2
            // 
            this.categoriaB2.AutoSize = true;
            this.categoriaB2.Location = new System.Drawing.Point(7, 43);
            this.categoriaB2.Name = "categoriaB2";
            this.categoriaB2.Size = new System.Drawing.Size(75, 17);
            this.categoriaB2.TabIndex = 1;
            this.categoriaB2.Text = "Supervisor";
            this.categoriaB2.UseVisualStyleBackColor = true;
            this.categoriaB2.CheckedChanged += new System.EventHandler(this.categoriaB2_CheckedChanged);
            // 
            // categoriaC2
            // 
            this.categoriaC2.AutoSize = true;
            this.categoriaC2.Location = new System.Drawing.Point(7, 66);
            this.categoriaC2.Name = "categoriaC2";
            this.categoriaC2.Size = new System.Drawing.Size(63, 17);
            this.categoriaC2.TabIndex = 2;
            this.categoriaC2.Text = "Gerente";
            this.categoriaC2.UseVisualStyleBackColor = true;
            this.categoriaC2.CheckedChanged += new System.EventHandler(this.categoriaC2_CheckedChanged);
            // 
            // lista
            // 
            this.lista.FormattingEnabled = true;
            this.lista.Location = new System.Drawing.Point(214, 16);
            this.lista.Name = "lista";
            this.lista.Size = new System.Drawing.Size(313, 21);
            this.lista.TabIndex = 1;
            this.lista.SelectedIndexChanged += new System.EventHandler(this.lista_SelectedIndexChanged);
            // 
            // botonSalida
            // 
            this.botonSalida.Location = new System.Drawing.Point(7, 142);
            this.botonSalida.Name = "botonSalida";
            this.botonSalida.Size = new System.Drawing.Size(123, 23);
            this.botonSalida.TabIndex = 2;
            this.botonSalida.Text = "Salida";
            this.botonSalida.UseVisualStyleBackColor = true;
            this.botonSalida.Click += new System.EventHandler(this.botonSalida_Click);
            // 
            // botonIngreso
            // 
            this.botonIngreso.Location = new System.Drawing.Point(6, 113);
            this.botonIngreso.Name = "botonIngreso";
            this.botonIngreso.Size = new System.Drawing.Size(123, 23);
            this.botonIngreso.TabIndex = 3;
            this.botonIngreso.Text = "Ingreso";
            this.botonIngreso.UseVisualStyleBackColor = true;
            this.botonIngreso.Click += new System.EventHandler(this.botonIngreso_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(282, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Total a Pagar Bs.";
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Location = new System.Drawing.Point(378, 77);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(13, 13);
            this.total.TabIndex = 6;
            this.total.Text = "0";
            // 
            // botonCancelar
            // 
            this.botonCancelar.Location = new System.Drawing.Point(285, 99);
            this.botonCancelar.Name = "botonCancelar";
            this.botonCancelar.Size = new System.Drawing.Size(242, 23);
            this.botonCancelar.TabIndex = 7;
            this.botonCancelar.Text = "Cancelar";
            this.botonCancelar.UseVisualStyleBackColor = true;
            this.botonCancelar.Click += new System.EventHandler(this.botonCancelar_Click);
            // 
            // registro
            // 
            this.registro.Location = new System.Drawing.Point(155, 128);
            this.registro.Name = "registro";
            this.registro.Size = new System.Drawing.Size(372, 139);
            this.registro.TabIndex = 8;
            this.registro.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(285, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(242, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Ver";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(545, 308);
            this.Controls.Add(this.Personal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Personal.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nombre;
        private System.Windows.Forms.TextBox carnet;
        private System.Windows.Forms.TextBox telefono;
        private System.Windows.Forms.Button botonRegistrar;
        private System.Windows.Forms.RadioButton categoriaA;
        private System.Windows.Forms.RadioButton categoriaC;
        private System.Windows.Forms.RadioButton categoriaB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl Personal;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button botonIngreso;
        private System.Windows.Forms.Button botonSalida;
        private System.Windows.Forms.ComboBox lista;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton categoriaC2;
        private System.Windows.Forms.RadioButton categoriaB2;
        private System.Windows.Forms.RadioButton categoriaA2;
        private System.Windows.Forms.Button botonCancelar;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.RichTextBox registro;
        private System.Windows.Forms.Button button1;
    }
}

