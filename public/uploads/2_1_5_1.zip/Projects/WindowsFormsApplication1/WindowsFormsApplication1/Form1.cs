﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        private Personal[] personal;
        private int cantidad;

        public Form1()
        {
            cantidad = 0;
            personal = new Personal[1000];
            InitializeComponent();
            //cargarLista(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (nombre.Text.Equals("") || carnet.Text.Equals("") || telefono.Text.Equals(""))
            {
                MessageBox.Show("LLene todos los campos");
            }
            else
            {
                bool existe = false;
                int i = 0;
                while (i < cantidad && !existe)
                {
                    if(personal[i].getCarnet().Equals(carnet.Text))
                    {
                        existe = true;
                        MessageBox.Show("Ese Carnet ya ha sido registrado");
                    }
                    i++;
                }
                if (!existe)
                {
                    int categoria = 0;
                    if(categoriaA.Checked)
                        categoria = 0;
                    else if(categoriaB.Checked)
                        categoria = 1;
                    else
                        categoria = 2;
                    personal[cantidad] = new Personal(nombre.Text, carnet.Text, telefono.Text, categoria);
                    MessageBox.Show("Correcto");
                    nombre.Text = "";
                    carnet.Text = "";
                    telefono.Text = "";
                    cantidad++;
                }
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void lista_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void categoriaA2_CheckedChanged(object sender, EventArgs e)
        {
            cargarLista(0);
        }

        private void categoriaB2_CheckedChanged(object sender, EventArgs e)
        {
            cargarLista(1);
        }

        private void categoriaC2_CheckedChanged(object sender, EventArgs e)
        {
            cargarLista(2);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int persona = buscarPersona();
            if (persona != -1)
            {
                registro.Text = personal[persona].getRegistro();
                total.Text = personal[persona].darTotal() + "";
            }
            else
                MessageBox.Show("Persona no encontrada");
        }

        private int buscarPersona()
        {
            int persona = -1;
            int i = 0;
            while (i < cantidad && persona == -1)
            {
                if (personal[i].toString().Equals(lista.SelectedItem.ToString()))
                    persona = i;
                i++;
            }
            return persona;
        }

        private void cargarLista(int ind)
        {
            lista.Items.Clear();
            for (int i = 0; i < cantidad; i++)
            {
                if (personal[i].getCategoria() == ind)
                    lista.Items.Add(personal[i].toString());
            }
        }

        private void botonIngreso_Click(object sender, EventArgs e)
        {
            int persona = buscarPersona();
            if (persona != -1)
            {
                personal[persona].ingresar();
                MessageBox.Show("Ingreso "+DateTime.Now.ToString());
            }
            else
            {
                MessageBox.Show("No selecciono");
            }
        }

        private void botonSalida_Click(object sender, EventArgs e)
        {
            int persona = buscarPersona();
            if (persona != -1 && personal[persona].Ingreso())
            {
                personal[persona].darSalario();
                MessageBox.Show("Salida " + DateTime.Now.ToString());
            }
            else if (personal[persona].Ingreso())
            {
                MessageBox.Show("No selecciono");
            }
            else
            {
                MessageBox.Show("No Ingreso");
            }
        }

        private void botonCancelar_Click(object sender, EventArgs e)
        {
            int persona = buscarPersona();
                if(persona != -1){
                    personal[persona].cancelar();
                    registro.Text = "";
                    total.Text = "0";
                    MessageBox.Show("Cuenta Cancelada");
                }
                else
                    MessageBox.Show("Seleccione un personal");

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
