/*==============================================================*/
/* DBMS name:      PostgreSQL 8                                 */
/* Created on:     05/04/2019 12:56:28                          */
/*==============================================================*/


drop index RELATIONSHIP_11_FK;

drop index ADMINISTRADOR_PK;

drop table ADMINISTRADOR;

drop index RELATIONSHIP_5_FK;

drop index RELATIONSHIP_4_FK;

drop table ASIGNA_FUNCION;

drop index RELATIONSHIP_3_FK;

drop index RELATIONSHIP_2_FK;

drop table ASIGNA_ROL;

drop index AULA_PK;

drop table AULA;

drop index RELATIONSHIP_32_FK;

drop index AUXILIAR_PK;

drop table AUXILIAR;

drop index RELATIONSHIP_28_FK;

drop index RELATIONSHIP_25_FK;

drop index RELATIONSHIP_24_FK;

drop index RELATIONSHIP_23_FK;

drop index CLASE_PK;

drop table CLASE;

drop index RELATIONSHIP_9_FK;

drop index DOCENTE_PK;

drop table DOCENTE;

drop index RELATIONSHIP_30_FK;

drop index ENVIO_PRACTICA_PK;

drop table ENVIO_PRACTICA;

drop index RELATIONSHIP_7_FK;

drop index ESTUDIANTE_PK;

drop table ESTUDIANTE;

drop index RELATIONSHIP_29_FK;

drop index RELATIONSHIP_19_FK;

drop table ESTUDIANTE_CLASE;

drop index FUNCION_PK;

drop table FUNCION;

drop index RELATIONSHIP_40_FK;

drop index GESTION_PK;

drop table GESTION;

drop index RELATIONSHIP_15_FK;

drop index GRUPO_A_DOCENTE_PK;

drop table GRUPO_A_DOCENTE;

drop index GRUPO_DOCENTE_PK;

drop table GRUPO_DOCENTE;

drop index RELATIONSHIP_37_FK;

drop index RELATIONSHIP_36_FK;

drop index GRUPO_DOCENTE_AUXILIAR_PK;

drop table GRUPO_DOCENTE_AUXILIAR;

drop index HORARIO_PK;

drop table HORARIO;

drop index RELATIONSHIP_1_FK;

drop index INICIAR_SESION_PK;

drop table INICIAR_SESION;

drop index PERIODO_PK;

drop table PERIODO;

drop index ROL_PK;

drop table ROL;

drop index RELATIONSHIP_27_FK;

drop index RELATIONSHIP_33_FK;

drop index SESION_PK;

drop table SESION;

drop index RELATIONSHIP_35_FK;

drop index RELATIONSHIP_34_FK;

drop index SESION_ESTUDIANTE_PK;

drop table SESION_ESTUDIANTE;

drop index RELATIONSHIP_31_FK;

drop index RELATIONSHIP_10_FK;

drop index RELATIONSHIP_8_FK;

drop index RELATIONSHIP_6_FK;

drop index USUARIO_PK;

drop table USUARIO;

/*==============================================================*/
/* Table: ADMINISTRADOR                                         */
/*==============================================================*/
create table ADMINISTRADOR (
   ID_ADMINISTRADOR     INT4                 not null,
   ID_USUARIO           INT4                 not null,
   constraint PK_ADMINISTRADOR primary key (ID_ADMINISTRADOR)
);

/*==============================================================*/
/* Index: ADMINISTRADOR_PK                                      */
/*==============================================================*/
create unique index ADMINISTRADOR_PK on ADMINISTRADOR (
ID_ADMINISTRADOR
);

/*==============================================================*/
/* Index: RELATIONSHIP_11_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_11_FK on ADMINISTRADOR (
ID_USUARIO
);

/*==============================================================*/
/* Table: ASIGNA_FUNCION                                        */
/*==============================================================*/
create table ASIGNA_FUNCION (
   ID_ROL               INT4                 null,
   ID_FUNCION           INT4                 not null,
   FECHA                DATE                 null
);

/*==============================================================*/
/* Index: RELATIONSHIP_4_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_4_FK on ASIGNA_FUNCION (
ID_ROL
);

/*==============================================================*/
/* Index: RELATIONSHIP_5_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_5_FK on ASIGNA_FUNCION (
ID_FUNCION
);

/*==============================================================*/
/* Table: ASIGNA_ROL                                            */
/*==============================================================*/
create table ASIGNA_ROL (
   ID_ROL               INT4                 null,
   ID_USUARIO           INT4                 not null
);

/*==============================================================*/
/* Index: RELATIONSHIP_2_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_2_FK on ASIGNA_ROL (
ID_USUARIO
);

/*==============================================================*/
/* Index: RELATIONSHIP_3_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_3_FK on ASIGNA_ROL (
ID_ROL
);

/*==============================================================*/
/* Table: AULA                                                  */
/*==============================================================*/
create table AULA (
   ID_AULA              SERIAL               not null,
   CODIGO_AULA          VARCHAR(25)          not null,
   NOMBRE_AULA          VARCHAR(50)          not null,
   DETALLE_AULA         VARCHAR(255)         null,
   constraint PK_AULA primary key (ID_AULA)
);

/*==============================================================*/
/* Index: AULA_PK                                               */
/*==============================================================*/
create unique index AULA_PK on AULA (
ID_AULA
);

/*==============================================================*/
/* Table: AUXILIAR                                              */
/*==============================================================*/
create table AUXILIAR (
   ID_AUXILIAR          INT4                 not null,
   ID_USUARIO           INT4                 not null,
   constraint PK_AUXILIAR primary key (ID_AUXILIAR)
);

/*==============================================================*/
/* Index: AUXILIAR_PK                                           */
/*==============================================================*/
create unique index AUXILIAR_PK on AUXILIAR (
ID_AUXILIAR
);

/*==============================================================*/
/* Index: RELATIONSHIP_32_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_32_FK on AUXILIAR (
ID_USUARIO
);

/*==============================================================*/
/* Table: CLASE                                                 */
/*==============================================================*/
create table CLASE (
   ID_CLASE             SERIAL               not null,
   ID_AULA              INT4                 not null,
   ID_HORARIO           INT4                 not null,
   ID_GRUPO_A_DOCENTE   INT4                 not null,
   ID_GESTION           INT4                 not null,
   DETALLE_CLASE        VARCHAR(255)         null,
   DIA                  NUMERIC(1)           not null,
   constraint PK_CLASE primary key (ID_CLASE)
);

/*==============================================================*/
/* Index: CLASE_PK                                              */
/*==============================================================*/
create unique index CLASE_PK on CLASE (
ID_CLASE
);

/*==============================================================*/
/* Index: RELATIONSHIP_23_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_23_FK on CLASE (
ID_AULA
);

/*==============================================================*/
/* Index: RELATIONSHIP_24_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_24_FK on CLASE (
ID_HORARIO
);

/*==============================================================*/
/* Index: RELATIONSHIP_25_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_25_FK on CLASE (
ID_GRUPO_A_DOCENTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_28_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_28_FK on CLASE (
ID_GESTION
);

/*==============================================================*/
/* Table: DOCENTE                                               */
/*==============================================================*/
create table DOCENTE (
   ID_DOCENTE           INT4                 not null,
   ID_USUARIO           INT4                 not null,
   constraint PK_DOCENTE primary key (ID_DOCENTE)
);

/*==============================================================*/
/* Index: DOCENTE_PK                                            */
/*==============================================================*/
create unique index DOCENTE_PK on DOCENTE (
ID_DOCENTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_9_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_9_FK on DOCENTE (
ID_USUARIO
);

/*==============================================================*/
/* Table: ENVIO_PRACTICA                                        */
/*==============================================================*/
create table ENVIO_PRACTICA (
   ID_ENVIO_PRACTICA    INT4                 not null,
   ID_SESION_ESTUDIANTE INT4                 not null,
   EN_LABORATORIO       BOOL                 not null,
   ARCHIVO              VARCHAR(255)         not null,
   constraint PK_ENVIO_PRACTICA primary key (ID_ENVIO_PRACTICA)
);

/*==============================================================*/
/* Index: ENVIO_PRACTICA_PK                                     */
/*==============================================================*/
create unique index ENVIO_PRACTICA_PK on ENVIO_PRACTICA (
ID_ENVIO_PRACTICA
);

/*==============================================================*/
/* Index: RELATIONSHIP_30_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_30_FK on ENVIO_PRACTICA (
ID_SESION_ESTUDIANTE
);

/*==============================================================*/
/* Table: ESTUDIANTE                                            */
/*==============================================================*/
create table ESTUDIANTE (
   ID_ESTUDIANTE        INT4                 not null,
   ID_USUARIO           INT4                 not null,
   CODIGO_SIS           NUMERIC(9)           not null,
   constraint PK_ESTUDIANTE primary key (ID_ESTUDIANTE)
);

/*==============================================================*/
/* Index: ESTUDIANTE_PK                                         */
/*==============================================================*/
create unique index ESTUDIANTE_PK on ESTUDIANTE (
ID_ESTUDIANTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_7_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_7_FK on ESTUDIANTE (
ID_USUARIO
);

/*==============================================================*/
/* Table: ESTUDIANTE_CLASE                                      */
/*==============================================================*/
create table ESTUDIANTE_CLASE (
   ID_CLASE             INT4                 not null,
   ID_ESTUDIANTE        INT4                 not null
);

/*==============================================================*/
/* Index: RELATIONSHIP_19_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_19_FK on ESTUDIANTE_CLASE (
ID_ESTUDIANTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_29_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_29_FK on ESTUDIANTE_CLASE (
ID_CLASE
);

/*==============================================================*/
/* Table: FUNCION                                               */
/*==============================================================*/
create table FUNCION (
   ID_FUNCION           SERIAL               not null,
   DESCRIPCION          VARCHAR(255)         null,
   constraint PK_FUNCION primary key (ID_FUNCION)
);

/*==============================================================*/
/* Index: FUNCION_PK                                            */
/*==============================================================*/
create unique index FUNCION_PK on FUNCION (
ID_FUNCION
);

/*==============================================================*/
/* Table: GESTION                                               */
/*==============================================================*/
create table GESTION (
   ID_GESTION           INT4                 not null,
   ID_PERIODO           INT4                 not null,
   ANO_GESTION          NUMERIC(4)           not null,
   constraint PK_GESTION primary key (ID_GESTION)
);

/*==============================================================*/
/* Index: GESTION_PK                                            */
/*==============================================================*/
create unique index GESTION_PK on GESTION (
ID_GESTION
);

/*==============================================================*/
/* Index: RELATIONSHIP_40_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_40_FK on GESTION (
ID_PERIODO
);

/*==============================================================*/
/* Table: GRUPO_A_DOCENTE                                       */
/*==============================================================*/
create table GRUPO_A_DOCENTE (
   ID_GRUPO_A_DOCENTE   INT4                 not null,
   ID_GRUPO_DOCENTE     INT4                 not null,
   ID_DOCENTE           INT4                 not null,
   FECHA_ASIGNAR_GRUPO_A_DOCENTE DATE                 null,
   constraint PK_GRUPO_A_DOCENTE primary key (ID_GRUPO_A_DOCENTE)
);

/*==============================================================*/
/* Index: GRUPO_A_DOCENTE_PK                                    */
/*==============================================================*/
create unique index GRUPO_A_DOCENTE_PK on GRUPO_A_DOCENTE (
ID_GRUPO_A_DOCENTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_15_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_15_FK on GRUPO_A_DOCENTE (
ID_DOCENTE
);

/*==============================================================*/
/* Table: GRUPO_DOCENTE                                         */
/*==============================================================*/
create table GRUPO_DOCENTE (
   ID_GRUPO_DOCENTE     SERIAL               not null,
   ID_MATERIA           INT4                 not null,
   DETALLE_GRUPO_DEOCENTE VARCHAR(255)         null,
   constraint PK_GRUPO_DOCENTE primary key (ID_GRUPO_DOCENTE)
);

/*==============================================================*/
/* Index: GRUPO_DOCENTE_PK                                      */
/*==============================================================*/
create unique index GRUPO_DOCENTE_PK on GRUPO_DOCENTE (
ID_GRUPO_DOCENTE
);

/*==============================================================*/
/* Table: GRUPO_DOCENTE_AUXILIAR                                */
/*==============================================================*/
create table GRUPO_DOCENTE_AUXILIAR (
   ID_GRUPO_DOCENTE_AUXILIAR CHAR(10)             null,
   ID_GRUPO_DOCENTE     INT4                 null,
   ID_AUXILIAR          INT4                 null,
   constraint PK_GRUPO_DOCENTE_AUXILIAR primary key ()
);

/*==============================================================*/
/* Index: GRUPO_DOCENTE_AUXILIAR_PK                             */
/*==============================================================*/
create unique index GRUPO_DOCENTE_AUXILIAR_PK on GRUPO_DOCENTE_AUXILIAR (

);

/*==============================================================*/
/* Index: RELATIONSHIP_36_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_36_FK on GRUPO_DOCENTE_AUXILIAR (
ID_GRUPO_DOCENTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_37_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_37_FK on GRUPO_DOCENTE_AUXILIAR (
ID_AUXILIAR
);

/*==============================================================*/
/* Table: HORARIO                                               */
/*==============================================================*/
create table HORARIO (
   ID_HORARIO           SERIAL               not null,
   HORA_INICIO          TIME                 not null,
   HORA_FIN             TIME                 not null,
   constraint PK_HORARIO primary key (ID_HORARIO)
);

/*==============================================================*/
/* Index: HORARIO_PK                                            */
/*==============================================================*/
create unique index HORARIO_PK on HORARIO (
ID_HORARIO
);

/*==============================================================*/
/* Table: INICIAR_SESION                                        */
/*==============================================================*/
create table INICIAR_SESION (
   ID_INICIAR_SESION    SERIAL               not null,
   ID_USUARIO           INT4                 not null,
   PID                  INT4                 not null,
   FECHA_INICIO         DATE                 null,
   FECHA_FIN            DATE                 null,
   constraint PK_INICIAR_SESION primary key (ID_INICIAR_SESION)
);

/*==============================================================*/
/* Index: INICIAR_SESION_PK                                     */
/*==============================================================*/
create unique index INICIAR_SESION_PK on INICIAR_SESION (
ID_INICIAR_SESION
);

/*==============================================================*/
/* Index: RELATIONSHIP_1_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_1_FK on INICIAR_SESION (
ID_USUARIO
);

/*==============================================================*/
/* Table: PERIODO                                               */
/*==============================================================*/
create table PERIODO (
   ID_PERIODO           INT4                 not null,
   DESCRIPCION          VARCHAR(255)         not null,
   constraint PK_PERIODO primary key (ID_PERIODO)
);

/*==============================================================*/
/* Index: PERIODO_PK                                            */
/*==============================================================*/
create unique index PERIODO_PK on PERIODO (
ID_PERIODO
);

/*==============================================================*/
/* Table: ROL                                                   */
/*==============================================================*/
create table ROL (
   ID_ROL               SERIAL               not null,
   DESCRIPCION          VARCHAR(255)         null,
   constraint PK_ROL primary key (ID_ROL)
);

/*==============================================================*/
/* Index: ROL_PK                                                */
/*==============================================================*/
create unique index ROL_PK on ROL (
ID_ROL
);

/*==============================================================*/
/* Table: SESION                                                */
/*==============================================================*/
create table SESION (
   ID_SESION            INT4                 not null,
   ID_CLASE             INT4                 not null,
   ID_AUXILIAR          INT4                 null,
   GUIA_PRACTICA        VARCHAR(255)         not null,
   DETALLE_PRACTICA     TEXT                 null,
   constraint PK_SESION primary key (ID_SESION)
);

/*==============================================================*/
/* Index: SESION_PK                                             */
/*==============================================================*/
create unique index SESION_PK on SESION (
ID_SESION
);

/*==============================================================*/
/* Index: RELATIONSHIP_33_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_33_FK on SESION (
ID_CLASE
);

/*==============================================================*/
/* Index: RELATIONSHIP_27_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_27_FK on SESION (
ID_AUXILIAR
);

/*==============================================================*/
/* Table: SESION_ESTUDIANTE                                     */
/*==============================================================*/
create table SESION_ESTUDIANTE (
   ID_SESION_ESTUDIANTE INT4                 not null,
   ID_ESTUDIANTE        INT4                 not null,
   ID_SESION            INT4                 not null,
   ASISTENCIA_SESION    BOOL                 not null,
   COMENTARIO_AUXILIAR  VARCHAR(255)         null,
   constraint PK_SESION_ESTUDIANTE primary key (ID_SESION_ESTUDIANTE)
);

/*==============================================================*/
/* Index: SESION_ESTUDIANTE_PK                                  */
/*==============================================================*/
create unique index SESION_ESTUDIANTE_PK on SESION_ESTUDIANTE (
ID_SESION_ESTUDIANTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_34_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_34_FK on SESION_ESTUDIANTE (
ID_SESION
);

/*==============================================================*/
/* Index: RELATIONSHIP_35_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_35_FK on SESION_ESTUDIANTE (
ID_ESTUDIANTE
);

/*==============================================================*/
/* Table: USUARIO                                               */
/*==============================================================*/
create table USUARIO (
   ID_USUARIO           SERIAL               not null,
   ID_ESTUDIANTE        INT4                 not null,
   ID_DOCENTE           INT4                 not null,
   ID_ADMINISTRADOR     INT4                 not null,
   ID_AUXILIAR          INT4                 not null,
   NOMBRE               VARCHAR(100)         not null,
   APELLIDO             VARCHAR(100)         not null,
   CORREO               VARCHAR(255)         not null,
   USERNAME             VARCHAR(25)          not null,
   PASSWORD             VARCHAR(255)         not null,
   constraint PK_USUARIO primary key (ID_USUARIO)
);

/*==============================================================*/
/* Index: USUARIO_PK                                            */
/*==============================================================*/
create unique index USUARIO_PK on USUARIO (
ID_USUARIO
);

/*==============================================================*/
/* Index: RELATIONSHIP_6_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_6_FK on USUARIO (
ID_ESTUDIANTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_8_FK                                     */
/*==============================================================*/
create  index RELATIONSHIP_8_FK on USUARIO (
ID_DOCENTE
);

/*==============================================================*/
/* Index: RELATIONSHIP_10_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_10_FK on USUARIO (
ID_ADMINISTRADOR
);

/*==============================================================*/
/* Index: RELATIONSHIP_31_FK                                    */
/*==============================================================*/
create  index RELATIONSHIP_31_FK on USUARIO (
ID_AUXILIAR
);

alter table ADMINISTRADOR
   add constraint FK_ADMINIST_RELATIONS_USUARIO foreign key (ID_USUARIO)
      references USUARIO (ID_USUARIO)
      on delete restrict on update restrict;

alter table ASIGNA_FUNCION
   add constraint FK_ASIGNA_F_RELATIONS_ROL foreign key (ID_ROL)
      references ROL (ID_ROL)
      on delete restrict on update restrict;

alter table ASIGNA_FUNCION
   add constraint FK_ASIGNA_F_RELATIONS_FUNCION foreign key (ID_FUNCION)
      references FUNCION (ID_FUNCION)
      on delete restrict on update restrict;

alter table ASIGNA_ROL
   add constraint FK_ASIGNA_R_RELATIONS_USUARIO foreign key (ID_USUARIO)
      references USUARIO (ID_USUARIO)
      on delete restrict on update restrict;

alter table ASIGNA_ROL
   add constraint FK_ASIGNA_R_RELATIONS_ROL foreign key (ID_ROL)
      references ROL (ID_ROL)
      on delete restrict on update restrict;

alter table AUXILIAR
   add constraint FK_AUXILIAR_RELATIONS_USUARIO foreign key (ID_USUARIO)
      references USUARIO (ID_USUARIO)
      on delete restrict on update restrict;

alter table CLASE
   add constraint FK_CLASE_RELATIONS_AULA foreign key (ID_AULA)
      references AULA (ID_AULA)
      on delete restrict on update restrict;

alter table CLASE
   add constraint FK_CLASE_RELATIONS_HORARIO foreign key (ID_HORARIO)
      references HORARIO (ID_HORARIO)
      on delete restrict on update restrict;

alter table CLASE
   add constraint FK_CLASE_RELATIONS_GRUPO_A_ foreign key (ID_GRUPO_A_DOCENTE)
      references GRUPO_A_DOCENTE (ID_GRUPO_A_DOCENTE)
      on delete restrict on update restrict;

alter table CLASE
   add constraint FK_CLASE_RELATIONS_GESTION foreign key (ID_GESTION)
      references GESTION (ID_GESTION)
      on delete restrict on update restrict;

alter table DOCENTE
   add constraint FK_DOCENTE_RELATIONS_USUARIO foreign key (ID_USUARIO)
      references USUARIO (ID_USUARIO)
      on delete restrict on update restrict;

alter table ENVIO_PRACTICA
   add constraint FK_ENVIO_PR_RELATIONS_SESION_E foreign key (ID_SESION_ESTUDIANTE)
      references SESION_ESTUDIANTE (ID_SESION_ESTUDIANTE)
      on delete restrict on update restrict;

alter table ESTUDIANTE
   add constraint FK_ESTUDIAN_RELATIONS_USUARIO foreign key (ID_USUARIO)
      references USUARIO (ID_USUARIO)
      on delete restrict on update restrict;

alter table ESTUDIANTE_CLASE
   add constraint FK_ESTUDIAN_RELATIONS_ESTUDIAN foreign key (ID_ESTUDIANTE)
      references ESTUDIANTE (ID_ESTUDIANTE)
      on delete restrict on update restrict;

alter table ESTUDIANTE_CLASE
   add constraint FK_ESTUDIAN_RELATIONS_CLASE foreign key (ID_CLASE)
      references CLASE (ID_CLASE)
      on delete restrict on update restrict;

alter table GESTION
   add constraint FK_GESTION_RELATIONS_PERIODO foreign key (ID_PERIODO)
      references PERIODO (ID_PERIODO)
      on delete restrict on update restrict;

alter table GRUPO_A_DOCENTE
   add constraint FK_GRUPO_A__RELATIONS_GRUPO_DO foreign key (ID_GRUPO_A_DOCENTE)
      references GRUPO_DOCENTE (ID_GRUPO_DOCENTE)
      on delete restrict on update restrict;

alter table GRUPO_A_DOCENTE
   add constraint FK_GRUPO_A__RELATIONS_DOCENTE foreign key (ID_DOCENTE)
      references DOCENTE (ID_DOCENTE)
      on delete restrict on update restrict;

alter table GRUPO_DOCENTE_AUXILIAR
   add constraint FK_GRUPO_DO_RELATIONS_GRUPO_DO foreign key (ID_GRUPO_DOCENTE)
      references GRUPO_DOCENTE (ID_GRUPO_DOCENTE)
      on delete restrict on update restrict;

alter table GRUPO_DOCENTE_AUXILIAR
   add constraint FK_GRUPO_DO_RELATIONS_AUXILIAR foreign key (ID_AUXILIAR)
      references AUXILIAR (ID_AUXILIAR)
      on delete restrict on update restrict;

alter table INICIAR_SESION
   add constraint FK_INICIAR__RELATIONS_USUARIO foreign key (ID_USUARIO)
      references USUARIO (ID_USUARIO)
      on delete restrict on update restrict;

alter table SESION
   add constraint FK_SESION_RELATIONS_AUXILIAR foreign key (ID_AUXILIAR)
      references AUXILIAR (ID_AUXILIAR)
      on delete restrict on update restrict;

alter table SESION
   add constraint FK_SESION_RELATIONS_CLASE foreign key (ID_CLASE)
      references CLASE (ID_CLASE)
      on delete restrict on update restrict;

alter table SESION_ESTUDIANTE
   add constraint FK_SESION_E_RELATIONS_SESION foreign key (ID_SESION)
      references SESION (ID_SESION)
      on delete restrict on update restrict;

alter table SESION_ESTUDIANTE
   add constraint FK_SESION_E_RELATIONS_ESTUDIAN foreign key (ID_ESTUDIANTE)
      references ESTUDIANTE (ID_ESTUDIANTE)
      on delete restrict on update restrict;

alter table USUARIO
   add constraint FK_USUARIO_RELATIONS_ADMINIST foreign key (ID_ADMINISTRADOR)
      references ADMINISTRADOR (ID_ADMINISTRADOR)
      on delete restrict on update restrict;

alter table USUARIO
   add constraint FK_USUARIO_RELATIONS_AUXILIAR foreign key (ID_AUXILIAR)
      references AUXILIAR (ID_AUXILIAR)
      on delete restrict on update restrict;

alter table USUARIO
   add constraint FK_USUARIO_RELATIONS_ESTUDIAN foreign key (ID_ESTUDIANTE)
      references ESTUDIANTE (ID_ESTUDIANTE)
      on delete restrict on update restrict;

alter table USUARIO
   add constraint FK_USUARIO_RELATIONS_DOCENTE foreign key (ID_DOCENTE)
      references DOCENTE (ID_DOCENTE)
      on delete restrict on update restrict;

